exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { reference } = JSON.parse(event.body);
    
    if (!reference) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Transaction reference is required' })
      };
    }

    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    
    if (!secretKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Server configuration error' })
      };
    }

    // Call Paystack API to verify transaction
    const response = await fetch(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${secretKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const data = await response.json();

    if (data.status && data.data) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          status: true,
          data: {
            status: data.data.status,
            reference: data.data.reference,
            amount: data.data.amount,
            paid_at: data.data.paid_at,
            channel: data.data.channel,
            currency: data.data.currency,
            customer: data.data.customer
          }
        })
      };
    } else {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          status: false,
          message: data.message || 'Could not verify transaction'
        })
      };
    }
  } catch (error) {
    console.error('Error verifying transaction:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        status: false,
        error: 'Internal server error',
        message: error.message 
      })
    };
  }
};