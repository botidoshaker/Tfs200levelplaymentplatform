exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { accountNumber, bankCode } = JSON.parse(event.body);
    
    if (!accountNumber || !bankCode) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Account number and bank code are required' })
      };
    }

    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    
    if (!secretKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Server configuration error' })
      };
    }

    // Call Paystack API to resolve account
    const response = await fetch(
      `https://api.paystack.co/bank/resolve?account_number=${accountNumber}&bank_code=${bankCode}`,
      {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${secretKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const data = await response.json();

    if (data.status && data.data) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          status: true,
          account_name: data.data.account_name,
          account_number: data.data.account_number
        })
      };
    } else {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          status: false,
          message: data.message || 'Could not resolve account'
        })
      };
    }
  } catch (error) {
    console.error('Error verifying bank account:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        status: false,
        error: 'Internal server error',
        message: error.message 
      })
    };
  }
};