import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { 
  Film, 
  GraduationCap, 
  Menu, 
  X,
  LogOut,
  Plus
} from 'lucide-react';
import type { User as UserType, Collection, Transaction } from './types';
import Home from './pages/Home';
import CreateCollection from './pages/CreateCollection';
import Contribute from './pages/Contribute';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import PaymentSuccess from './pages/PaymentSuccess';
import CollectionDetail from './pages/CollectionDetail';
import BankSettings from './pages/BankSettings';

function App() {
  const [user, setUser] = useState<UserType | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    const savedCollections = localStorage.getItem('collections');
    const savedTransactions = localStorage.getItem('transactions');
    
    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedCollections) setCollections(JSON.parse(savedCollections));
    if (savedTransactions) setTransactions(JSON.parse(savedTransactions));
  }, []);

  useEffect(() => {
    localStorage.setItem('collections', JSON.stringify(collections));
  }, [collections]);

  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions));
  }, [transactions]);

  const handleLogin = (userData: UserType) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleRegister = (userData: UserType) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const addCollection = (collection: Collection) => {
    setCollections(prev => [collection, ...prev]);
  };

  const addTransaction = (transaction: Transaction) => {
    setTransactions(prev => [transaction, ...prev]);
    
    // Update collection with paid member
    setCollections(prev => prev.map(col => {
      if (col.id === transaction.collectionId) {
        return {
          ...col,
          currentAmount: col.currentAmount + transaction.amount,
          paidMembers: [
            ...col.paidMembers,
            {
              id: transaction.id,
              fullName: transaction.fullName,
              regNumber: transaction.regNumber,
              phone: transaction.phone,
              email: transaction.email,
              amount: transaction.amount,
              paidAt: transaction.paidAt,
              transactionRef: transaction.transactionRef
            }
          ]
        };
      }
      return col;
    }));
  };

  const updateCollection = (updatedCollection: Collection) => {
    setCollections(prev => prev.map(col => 
      col.id === updatedCollection.id ? updatedCollection : col
    ));
  };

  const deleteCollection = (id: string) => {
    setCollections(prev => prev.filter(col => col.id !== id));
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {/* Navigation */}
        <nav className="bg-gradient-to-r from-purple-900 via-purple-800 to-indigo-900 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <Link to="/" className="flex items-center space-x-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <Film className="h-6 w-6" />
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-lg font-bold">200LV Theater</span>
                    <span className="text-xs block text-purple-200">& Film Studies</span>
                  </div>
                </Link>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center space-x-6">
                <Link to="/" className="hover:text-purple-200 transition-colors">Home</Link>
                {user ? (
                  <>
                    <Link to="/dashboard" className="hover:text-purple-200 transition-colors">Dashboard</Link>
                    <Link 
                      to="/create" 
                      className="bg-white text-purple-900 px-4 py-2 rounded-lg font-medium hover:bg-purple-100 transition-colors flex items-center space-x-2"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Create Payment</span>
                    </Link>
                    <div className="flex items-center space-x-3 ml-4 border-l border-white/30 pl-6">
                      <div className="text-right">
                        <p className="text-sm font-medium">{user.fullName}</p>
                        <p className="text-xs text-purple-200">{user.regNumber}</p>
                      </div>
                      <button 
                        onClick={handleLogout}
                        className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                        title="Logout"
                      >
                        <LogOut className="h-5 w-5" />
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <Link to="/login" className="hover:text-purple-200 transition-colors">Login</Link>
                    <Link to="/register" className="bg-white text-purple-900 px-4 py-2 rounded-lg font-medium hover:bg-purple-100 transition-colors">
                      Register
                    </Link>
                  </>
                )}
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden flex items-center">
                <button 
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="p-2 hover:bg-white/10 rounded-lg"
                >
                  {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                </button>
              </div>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden bg-purple-800 border-t border-white/10">
              <div className="px-4 pt-2 pb-4 space-y-1">
                <Link to="/" className="block px-3 py-2 rounded-md hover:bg-white/10" onClick={() => setIsMenuOpen(false)}>Home</Link>
                {user ? (
                  <>
                    <Link to="/dashboard" className="block px-3 py-2 rounded-md hover:bg-white/10" onClick={() => setIsMenuOpen(false)}>Dashboard</Link>
                    <Link to="/create" className="block px-3 py-2 rounded-md bg-white/20" onClick={() => setIsMenuOpen(false)}>Create Payment</Link>
                    <div className="border-t border-white/20 mt-2 pt-2">
                      <p className="px-3 py-1 text-sm text-purple-200">{user.fullName}</p>
                      <p className="px-3 py-1 text-xs text-purple-300">{user.regNumber}</p>
                      <button 
                        onClick={() => { handleLogout(); setIsMenuOpen(false); }}
                        className="w-full text-left px-3 py-2 text-red-200 hover:bg-white/10 rounded-md mt-2"
                      >
                        Logout
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <Link to="/login" className="block px-3 py-2 rounded-md hover:bg-white/10" onClick={() => setIsMenuOpen(false)}>Login</Link>
                    <Link to="/register" className="block px-3 py-2 rounded-md bg-white/20" onClick={() => setIsMenuOpen(false)}>Register</Link>
                  </>
                )}
              </div>
            </div>
          )}
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/login" element={<Login onLogin={handleLogin} />} />
          <Route path="/register" element={<Register onRegister={handleRegister} />} />
          <Route 
            path="/create" 
            element={
              user ? 
                <CreateCollection user={user} onCollectionCreated={addCollection} /> : 
                <Navigate to="/login" />
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              user ? 
                <Dashboard 
                  user={user} 
                  collections={collections} 
                  transactions={transactions}
                  onDeleteCollection={deleteCollection}
                /> : 
                <Navigate to="/login" />
            } 
          />
          <Route 
            path="/collection/:id" 
            element={
              user ? 
                <CollectionDetail 
                  user={user}
                  collections={collections}
                  onUpdateCollection={updateCollection}
                /> : 
                <Navigate to="/login" />
            } 
          />
          <Route 
            path="/settings/bank" 
            element={
              user ? 
                <BankSettings user={user} /> : 
                <Navigate to="/login" />
            } 
          />
          <Route 
            path="/contribute/:id" 
            element={
              <Contribute 
                collections={collections}
                onPaymentComplete={addTransaction}
              />
            } 
          />
          <Route path="/pay" element={<Navigate to="/contribute" replace />} />
          <Route path="/payment-success" element={<PaymentSuccess />} />
        </Routes>

        {/* Footer */}
        <footer className="bg-gray-900 text-gray-300 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <Film className="h-8 w-8 text-purple-400" />
                  <div>
                    <h3 className="text-lg font-bold text-white">200LV Theater</h3>
                    <p className="text-sm text-gray-400">& Film Studies</p>
                  </div>
                </div>
                <p className="text-sm text-gray-400">
                  Class payment platform for 200 Level Theater and Film Studies students.
                </p>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Quick Links</h4>
                <ul className="space-y-2 text-sm">
                  <li><Link to="/" className="hover:text-purple-400 transition-colors">Home</Link></li>
                  <li><Link to="/dashboard" className="hover:text-purple-400 transition-colors">Dashboard</Link></li>
                  <li><Link to="/create" className="hover:text-purple-400 transition-colors">Create Payment</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Contact</h4>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center space-x-2">
                    <span>Department of Theater & Film Studies</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <span>200 Level Class Rep</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-semibold mb-4">Powered By</h4>
                <p className="text-sm text-gray-400">Judexbeast TFS200LV</p>
                <p className="text-sm text-gray-400">Payment Platform</p>
                <div className="mt-4 flex items-center space-x-2 text-xs text-gray-500">
                  <GraduationCap className="h-4 w-4" />
                  <span>Secure Class Payments</span>
                </div>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-500">
              <p>&copy; {new Date().getFullYear()} 200LV Theater & Film Studies. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
