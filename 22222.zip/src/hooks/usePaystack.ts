import { useState, useCallback } from 'react';

const PAYSTACK_PUBLIC_KEY = 'pk_test_9721481771baa92fa5c2c78e1c94f2b61ecdd38b';

interface PaystackConfig {
  email: string;
  amount: number;
  reference: string;
  currency?: string;
  callback?: (response: PaystackResponse) => void;
  onClose?: () => void;
}

interface PaystackResponse {
  reference: string;
  status: 'success' | 'failed' | 'abandoned';
  trans: string;
  transaction: string;
  message: string;
}

// Load Paystack script
const loadPaystackScript = () => {
  if (typeof window !== 'undefined' && !document.getElementById('paystack-script')) {
    const script = document.createElement('script');
    script.id = 'paystack-script';
    script.src = 'https://js.paystack.co/v1/inline.js';
    script.async = true;
    document.body.appendChild(script);
  }
};

if (typeof window !== 'undefined') {
  loadPaystackScript();
}

export function usePaystack() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const initializePayment = useCallback((config: PaystackConfig) => {
    setIsLoading(true);
    setError(null);

    return new Promise<PaystackResponse>((resolve, reject) => {
      const checkPaystack = setInterval(() => {
        if (window.PaystackPop) {
          clearInterval(checkPaystack);

          const handler = window.PaystackPop.setup({
            key: PAYSTACK_PUBLIC_KEY,
            email: config.email,
            amount: config.amount * 100, // Convert to kobo
            ref: config.reference,
            currency: config.currency || 'NGN',
            callback: (response: { reference: string }) => {
              setIsLoading(false);
              const fullResponse: PaystackResponse = {
                reference: response.reference,
                status: 'success',
                trans: '',
                transaction: '',
                message: 'Payment successful',
              };
              config.callback?.(fullResponse);
              resolve(fullResponse);
            },
            onClose: () => {
              setIsLoading(false);
              config.onClose?.();
              reject(new Error('Payment cancelled'));
            },
          });

          handler.openIframe();
        }
      }, 100);

      // Timeout after 10 seconds
      setTimeout(() => {
        clearInterval(checkPaystack);
        setIsLoading(false);
        reject(new Error('Paystack failed to load'));
      }, 10000);
    });
  }, []);

  return { initializePayment, isLoading, error };
}

export async function verifyPaystackTransaction(reference: string): Promise<{
  status: boolean;
  data?: {
    status: string;
    reference: string;
    amount: number;
    paid_at: string;
    channel: string;
    currency: string;
    authorization?: {
      card_type?: string;
      last4?: string;
      bank?: string;
    };
  };
}> {
  // In production, this should be done on your backend
  // For demo, we simulate the verification
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        status: true,
        data: {
          status: 'success',
          reference: reference,
          amount: 5000 * 100,
          paid_at: new Date().toISOString(),
          channel: 'card',
          currency: 'NGN',
          authorization: {
            card_type: 'visa',
            last4: '4081',
            bank: 'Test Bank',
          },
        },
      });
    }, 2000);
  });
}


