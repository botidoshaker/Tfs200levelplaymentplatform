import { useState, useEffect } from 'react';
import { User } from './useAuth';

export interface Collection {
  id: string;
  title: string;
  description: string;
  amount: number;
  currency: string;
  type: 'fixed' | 'target' | 'open';
  targetAmount?: number;
  expiryDate?: string;
  createdBy: string;
  creatorName: string;
  creatorRegNumber: string;
  createdAt: string;
  shareUrl: string;
  payments: Payment[];
}

export interface Payment {
  id: string;
  reference: string;
  fullName: string;
  regNumber: string;
  email: string;
  phone: string;
  amount: number;
  currency: string;
  status: 'pending' | 'success' | 'failed';
  paymentMethod: 'card' | 'bank' | 'ussd' | 'qr';
  paidAt?: string;
  verifiedAt?: string;
  verifiedBy?: string;
  paystackData?: any;
}

export const useCollections = (user: User | null) => {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);

  useEffect(() => {
    const storedCollections = localStorage.getItem('tfs_collections');
    const storedPayments = localStorage.getItem('tfs_payments');
    
    if (storedCollections) {
      try {
        setCollections(JSON.parse(storedCollections));
      } catch (e) {
        console.error('Error parsing collections:', e);
      }
    }
    
    if (storedPayments) {
      try {
        setPayments(JSON.parse(storedPayments));
      } catch (e) {
        console.error('Error parsing payments:', e);
      }
    }
  }, []);

  const saveCollections = (newCollections: Collection[]) => {
    setCollections(newCollections);
    localStorage.setItem('tfs_collections', JSON.stringify(newCollections));
  };

  const savePayments = (newPayments: Payment[]) => {
    setPayments(newPayments);
    localStorage.setItem('tfs_payments', JSON.stringify(newPayments));
  };

  const createCollection = (collectionData: Omit<Collection, 'id' | 'createdAt' | 'shareUrl' | 'payments' | 'createdBy' | 'creatorName' | 'creatorRegNumber'>): Collection => {
    const id = `col_${Date.now().toString(36)}`;
    const newCollection: Collection = {
      ...collectionData,
      id,
      createdBy: user?.id || '',
      creatorName: user?.fullName || '',
      creatorRegNumber: user?.regNumber || '',
      createdAt: new Date().toISOString(),
      shareUrl: `${window.location.origin}/contribute/${id}`,
      payments: [],
    };

    const updatedCollections = [...collections, newCollection];
    saveCollections(updatedCollections);
    return newCollection;
  };

  const getCollection = (id: string): Collection | undefined => {
    return collections.find(c => c.id === id);
  };

  const addPayment = (collectionId: string, payment: Omit<Payment, 'id'>): Payment => {
    const newPayment: Payment = {
      ...payment,
      id: `pay_${Date.now().toString(36)}`,
    };

    // Update collection payments
    const updatedCollections = collections.map(c => {
      if (c.id === collectionId) {
        return {
          ...c,
          payments: [...c.payments, newPayment],
        };
      }
      return c;
    });
    saveCollections(updatedCollections);

    // Add to global payments
    const updatedPayments = [...payments, newPayment];
    savePayments(updatedPayments);

    return newPayment;
  };

  const verifyPayment = (paymentId: string, verifiedBy: string): boolean => {
    const payment = payments.find(p => p.id === paymentId);
    if (!payment) return false;

    const updatedPayment = {
      ...payment,
      status: 'success' as const,
      verifiedAt: new Date().toISOString(),
      verifiedBy,
    };

    // Update in payments array
    const updatedPayments = payments.map(p => 
      p.id === paymentId ? updatedPayment : p
    );
    savePayments(updatedPayments);

    // Update in collection
    const updatedCollections = collections.map(c => ({
      ...c,
      payments: c.payments.map(p => 
        p.id === paymentId ? updatedPayment : p
      ),
    }));
    saveCollections(updatedCollections);

    return true;
  };

  const updatePaymentStatus = (reference: string, status: Payment['status'], paystackData?: any): boolean => {
    const payment = payments.find(p => p.reference === reference);
    if (!payment) return false;

    const updatedPayment = {
      ...payment,
      status,
      paystackData,
      paidAt: status === 'success' ? new Date().toISOString() : payment.paidAt,
    };

    // Update in payments array
    const updatedPayments = payments.map(p => 
      p.reference === reference ? updatedPayment : p
    );
    savePayments(updatedPayments);

    // Update in collection
    const updatedCollections = collections.map(c => ({
      ...c,
      payments: c.payments.map(p => 
        p.reference === reference ? updatedPayment : p
      ),
    }));
    saveCollections(updatedCollections);

    return true;
  };

  const getUserCollections = (userId: string): Collection[] => {
    return collections.filter(c => c.createdBy === userId);
  };

  const getUserPayments = (userId: string): Payment[] => {
    const userCollectionIds = collections
      .filter(c => c.createdBy === userId)
      .map(c => c.id);
    
    return payments.filter(p => 
      userCollectionIds.some(collectionId => 
        collections.find(c => c.id === collectionId)?.payments.some(cp => cp.id === p.id)
      )
    );
  };

  const getPendingVerifications = (userId: string): Payment[] => {
    const userCollections = collections.filter(c => c.createdBy === userId);
    const pendingPayments: Payment[] = [];
    
    userCollections.forEach(collection => {
      collection.payments.forEach(payment => {
        if (payment.status === 'pending') {
          pendingPayments.push(payment);
        }
      });
    });
    
    return pendingPayments;
  };

  const getTotalEarnings = (userId: string): number => {
    const userCollections = collections.filter(c => c.createdBy === userId);
    let total = 0;
    
    userCollections.forEach(collection => {
      collection.payments.forEach(payment => {
        if (payment.status === 'success') {
          total += payment.amount;
        }
      });
    });
    
    return total;
  };

  const deleteCollection = (id: string): boolean => {
    const updatedCollections = collections.filter(c => c.id !== id);
    saveCollections(updatedCollections);
    return true;
  };

  return {
    collections,
    payments,
    createCollection,
    getCollection,
    addPayment,
    verifyPayment,
    updatePaymentStatus,
    getUserCollections,
    getUserPayments,
    getPendingVerifications,
    getTotalEarnings,
    deleteCollection,
  };
};