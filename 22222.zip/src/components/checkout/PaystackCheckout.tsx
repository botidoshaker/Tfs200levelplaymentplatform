import React, { useState, useEffect, useCallback } from 'react';
import { 
  X, 
  CreditCard, 
  Building2, 
  Smartphone, 
  QrCode, 
  Lock,
  Check,
  AlertCircle,
  Timer,
  Copy,
  ChevronRight,
  Loader2
} from 'lucide-react';
import { 
  loadPaystackScript, 
  payWithPaystack, 
  verifyTransaction,
  pollPaymentStatus
} from '../../services/paystackService';
import { generateId } from '../../utils/helpers';

interface PaystackCheckoutProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  email: string;
  phone: string;
  metadata: {
    fullName: string;
    regNumber: string;
    collectionId: string;
    collectionTitle: string;
    customFields?: any[];
  };
  hostBankDetails?: {
    bankName: string;
    accountNumber: string;
    accountName: string;
  } | null;
  onSuccess: (reference: string, paymentData: any) => void;
  onPending: (reference: string) => void;
}

type PaymentMethod = 'card' | 'bank' | 'ussd' | 'qr';
type PaymentStatus = 'input' | 'processing' | 'verifying' | 'success' | 'failed' | 'pending';

const PaystackCheckout: React.FC<PaystackCheckoutProps> = ({
  isOpen,
  onClose,
  amount,
  email,
  phone,
  metadata,
  hostBankDetails,
  onSuccess,
  onPending,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [status, setStatus] = useState<PaymentStatus>('input');
  const [reference, setReference] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [countdown, setCountdown] = useState<number>(1800); // 30 minutes
  const [isLoading, setIsLoading] = useState(false);
  const [copiedField, setCopiedField] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      loadPaystackScript().catch(console.error);
      setReference(`TFS_${generateId().substring(0, 8).toUpperCase()}`);
    }
  }, [isOpen]);

  // Countdown timer for bank transfer
  useEffect(() => {
    if (status === 'pending' && countdown > 0) {
      const timer = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (countdown === 0) {
      setStatus('failed');
      setError('Payment session expired. Please try again.');
    }
  }, [status, countdown]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(''), 2000);
  };

  const verifyPayment = useCallback(async (ref: string) => {
    setStatus('verifying');
    
    try {
      const result = await verifyTransaction(ref);
      
      if (result.status && result.data) {
        if (result.data.status === 'success') {
          setStatus('success');
          onSuccess(ref, result.data);
        } else if (result.data.status === 'failed') {
          setStatus('failed');
          setError('Payment failed. Please try again.');
        } else {
          // Still pending, continue polling
          setStatus('pending');
          startPolling(ref);
        }
      } else {
        setStatus('pending');
        startPolling(ref);
      }
    } catch (err) {
      setStatus('pending');
      startPolling(ref);
    }
  }, [onSuccess]);

  const startPolling = (ref: string) => {
    pollPaymentStatus(
      ref,
      (paymentStatus, data) => {
        if (paymentStatus === 'success') {
          setStatus('success');
          onSuccess(ref, data);
        } else if (paymentStatus === 'failed') {
          setStatus('failed');
          setError('Payment was not completed.');
        } else if (paymentStatus === 'timeout') {
          setStatus('failed');
          setError('Payment verification timed out. Please contact support.');
        }
      },
      60, // max attempts
      5000 // 5 second interval
    );
  };

  const handleCardPayment = () => {
    setIsLoading(true);
    setError('');

    payWithPaystack(
      email,
      amount,
      reference,
      {
        ...metadata,
        phone,
        custom_fields: [
          {
            display_name: "Full Name",
            variable_name: "full_name",
            value: metadata.fullName,
          },
          {
            display_name: "Registration Number",
            variable_name: "reg_number",
            value: metadata.regNumber,
          },
        ],
      },
      (successRef) => {
        setIsLoading(false);
        verifyPayment(successRef);
      },
      () => {
        setIsLoading(false);
        setError('Payment cancelled. Please try again.');
      }
    );
  };

  const handleBankTransfer = () => {
    if (!hostBankDetails) {
      setError('Bank transfer not available. Please use card payment.');
      return;
    }
    
    setStatus('pending');
    setCountdown(1800); // 30 minutes
    onPending(reference);
    
    // Start polling for this reference
    startPolling(reference);
  };

  const handleUSSDPayment = () => {
    setError('USSD payment will open in your dialer. Please complete the payment and click "I\'ve Paid".');
    
    // Generate USSD code based on amount
    const ussdCode = `*389*1*${amount}#`;
    window.location.href = `tel:${ussdCode}`;
    
    setStatus('pending');
    setCountdown(1800);
    onPending(reference);
    startPolling(reference);
  };

  const handleQRPayment = () => {
    setStatus('pending');
    setCountdown(1800);
    onPending(reference);
    startPolling(reference);
  };

  const handlePayment = () => {
    switch (paymentMethod) {
      case 'card':
        handleCardPayment();
        break;
      case 'bank':
        handleBankTransfer();
        break;
      case 'ussd':
        handleUSSDPayment();
        break;
      case 'qr':
        handleQRPayment();
        break;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-violet-600 to-purple-600 p-6 text-white">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 text-white/80 text-sm mb-1">
                <Lock className="w-4 h-4" />
                <span>Secured by Paystack</span>
              </div>
              <h2 className="text-2xl font-bold">Pay {metadata.collectionTitle}</h2>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="mt-4">
            <span className="text-white/70 text-sm">Amount to Pay</span>
            <div className="text-3xl font-bold">₦{amount.toLocaleString()}</div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {/* Success State */}
          {status === 'success' && (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Payment Successful!</h3>
              <p className="text-gray-600 mb-4">Your payment has been confirmed.</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Reference</p>
                <p className="font-mono font-semibold">{reference}</p>
              </div>
              <button
                onClick={onClose}
                className="mt-6 w-full py-3 bg-violet-600 text-white rounded-xl font-semibold hover:bg-violet-700 transition-colors"
              >
                Done
              </button>
            </div>
          )}

          {/* Failed State */}
          {status === 'failed' && (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-10 h-10 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Payment Failed</h3>
              <p className="text-gray-600 mb-4">{error || 'Unable to complete payment.'}</p>
              <button
                onClick={() => {
                  setStatus('input');
                  setError('');
                  setReference(`TFS_${generateId().substring(0, 8).toUpperCase()}`);
                }}
                className="w-full py-3 bg-violet-600 text-white rounded-xl font-semibold hover:bg-violet-700 transition-colors"
              >
                Try Again
              </button>
            </div>
          )}

          {/* Pending State - Bank Transfer */}
          {status === 'pending' && paymentMethod === 'bank' && hostBankDetails && (
            <div className="space-y-4">
              <div className="text-center">
                <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                  <Timer className="w-4 h-4" />
                  <span>Expires in {formatTime(countdown)}</span>
                </div>
                <p className="text-gray-600">Transfer ₦{amount.toLocaleString()} to:</p>
              </div>

              <div className="bg-gray-50 p-4 rounded-xl space-y-3">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Bank Name</p>
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-gray-900">{hostBankDetails.bankName}</p>
                    <button
                      onClick={() => handleCopy(hostBankDetails.bankName, 'bank')}
                      className="text-violet-600 hover:text-violet-700"
                    >
                      {copiedField === 'bank' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-gray-500 mb-1">Account Number</p>
                  <div className="flex items-center justify-between">
                    <p className="font-mono text-lg font-bold text-gray-900">{hostBankDetails.accountNumber}</p>
                    <button
                      onClick={() => handleCopy(hostBankDetails.accountNumber, 'account')}
                      className="text-violet-600 hover:text-violet-700"
                    >
                      {copiedField === 'account' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-gray-500 mb-1">Account Name</p>
                  <p className="font-semibold text-gray-900">{hostBankDetails.accountName}</p>
                </div>

                <div>
                  <p className="text-xs text-gray-500 mb-1">Amount</p>
                  <p className="font-mono text-lg font-bold text-violet-600">₦{amount.toLocaleString()}</p>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
                <p className="text-sm text-blue-800">
                  <strong>Important:</strong> Use this reference when transferring:
                </p>
                <div className="flex items-center justify-between mt-2 bg-white p-2 rounded">
                  <code className="font-mono text-sm">{reference}</code>
                  <button
                    onClick={() => handleCopy(reference, 'ref')}
                    className="text-violet-600 hover:text-violet-700"
                  >
                    {copiedField === 'ref' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <p className="text-sm text-gray-600 text-center">
                Your payment will be verified automatically once received.
              </p>

              <button
                onClick={onClose}
                className="w-full py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
              >
                I'll Transfer Later
              </button>
            </div>
          )}

          {/* Pending State - Other Methods */}
          {status === 'pending' && paymentMethod !== 'bank' && (
            <div className="text-center py-8">
              <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Verifying Payment...</span>
              </div>
              <p className="text-gray-600 mb-4">
                Please complete your payment. We're monitoring for confirmation.
              </p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Reference</p>
                <p className="font-mono font-semibold">{reference}</p>
              </div>
            </div>
          )}

          {/* Verifying State */}
          {status === 'verifying' && (
            <div className="text-center py-12">
              <Loader2 className="w-12 h-12 text-violet-600 animate-spin mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900">Verifying Payment</h3>
              <p className="text-gray-600 mt-2">Please wait while we confirm your payment...</p>
            </div>
          )}

          {/* Input State - Payment Method Selection */}
          {status === 'input' && (
            <>
              {/* Customer Info Summary */}
              <div className="mb-6 p-4 bg-gray-50 rounded-xl">
                <p className="text-sm text-gray-600 mb-2">Paying as:</p>
                <p className="font-semibold text-gray-900">{metadata.fullName}</p>
                <p className="text-sm text-gray-600">{email}</p>
                <p className="text-sm text-gray-600">Reg: {metadata.regNumber}</p>
              </div>

              {/* Payment Methods */}
              <div className="space-y-3 mb-6">
                <p className="text-sm font-medium text-gray-700">Select Payment Method</p>
                
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`w-full p-4 rounded-xl border-2 flex items-center gap-4 transition-all ${
                    paymentMethod === 'card' 
                      ? 'border-violet-500 bg-violet-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`p-3 rounded-lg ${paymentMethod === 'card' ? 'bg-violet-200' : 'bg-gray-100'}`}>
                    <CreditCard className={`w-6 h-6 ${paymentMethod === 'card' ? 'text-violet-700' : 'text-gray-600'}`} />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-semibold text-gray-900">Card Payment or Bank Transfer</p>
                    <p className="text-sm text-gray-500">Pay with card, bank app, or transfer</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>

                {hostBankDetails && (
                  <button
                    onClick={() => setPaymentMethod('bank')}
                    className={`w-full p-4 rounded-xl border-2 flex items-center gap-4 transition-all ${
                      paymentMethod === 'bank' 
                        ? 'border-violet-500 bg-violet-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className={`p-3 rounded-lg ${paymentMethod === 'bank' ? 'bg-violet-200' : 'bg-gray-100'}`}>
                      <Building2 className={`w-6 h-6 ${paymentMethod === 'bank' ? 'text-violet-700' : 'text-gray-600'}`} />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-semibold text-gray-900">Bank Transfer</p>
                      <p className="text-sm text-gray-500">Transfer to {hostBankDetails.bankName}</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </button>
                )}

                <button
                  onClick={() => setPaymentMethod('ussd')}
                  className={`w-full p-4 rounded-xl border-2 flex items-center gap-4 transition-all ${
                    paymentMethod === 'ussd' 
                      ? 'border-violet-500 bg-violet-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`p-3 rounded-lg ${paymentMethod === 'ussd' ? 'bg-violet-200' : 'bg-gray-100'}`}>
                    <Smartphone className={`w-6 h-6 ${paymentMethod === 'ussd' ? 'text-violet-700' : 'text-gray-600'}`} />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-semibold text-gray-900">USSD</p>
                    <p className="text-sm text-gray-500">Dial code on your phone</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>

                <button
                  onClick={() => setPaymentMethod('qr')}
                  className={`w-full p-4 rounded-xl border-2 flex items-center gap-4 transition-all ${
                    paymentMethod === 'qr' 
                      ? 'border-violet-500 bg-violet-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`p-3 rounded-lg ${paymentMethod === 'qr' ? 'bg-violet-200' : 'bg-gray-100'}`}>
                    <QrCode className={`w-6 h-6 ${paymentMethod === 'qr' ? 'text-violet-700' : 'text-gray-600'}`} />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-semibold text-gray-900">QR Code</p>
                    <p className="text-sm text-gray-500">Scan with your banking app</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              {/* Pay Button */}
              <button
                onClick={handlePayment}
                disabled={isLoading}
                className="w-full py-4 bg-violet-600 text-white rounded-xl font-semibold text-lg hover:bg-violet-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>Pay ₦{amount.toLocaleString()}</>
                )}
              </button>

              <p className="text-center text-sm text-gray-500 mt-4">
                <Lock className="w-3 h-3 inline mr-1" />
                Secured by 256-bit SSL encryption
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaystackCheckout;