export interface User {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  regNumber?: string;
  createdAt: string;
}

export interface PaidMember {
  id: string;
  fullName: string;
  regNumber: string;
  phone: string;
  email: string;
  amount: number;
  paidAt: string;
  transactionRef: string;
}

export interface Collection {
  id: string;
  title: string;
  description: string;
  type: 'fixed' | 'target' | 'open';
  amount?: number;
  targetAmount?: number;
  currentAmount: number;
  currency: string;
  repName: string;
  repId: string;
  expiryDate?: string;
  createdAt: string;
  link: string;
  paidMembers: PaidMember[];
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    accountName: string;
  };
}

export interface Transaction {
  id: string;
  collectionId: string;
  collectionTitle: string;
  fullName: string;
  regNumber: string;
  phone: string;
  email: string;
  amount: number;
  currency: string;
  status: 'pending' | 'success' | 'failed';
  paymentMethod: string;
  transactionRef: string;
  paidAt: string;
}

export interface Payment {
  id: string;
  collectionId: string;
  payerName: string;
  payerRegNumber: string;
  payerEmail: string;
  payerPhone: string;
  amount: number;
  currency: string;
  status: 'completed' | 'pending' | 'failed' | 'abandoned';
  reference: string;
  paymentMethod: 'card' | 'bank_transfer' | 'ussd' | 'qr';
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    accountName: string;
  };
  createdAt: string;
  paidAt?: string;
  verifiedByPaystack: boolean;
  paystackData?: {
    channel: string;
    cardType?: string;
    last4?: string;
    bank?: string;
    paidAt: string;
  };
}

export interface BankAccount {
  id: string;
  userId: string;
  bankName: string;
  bankCode: string;
  accountNumber: string;
  accountName: string;
  isDefault: boolean;
  createdAt: string;
}

export interface Bank {
  name: string;
  code: string;
}

declare global {
  interface Window {
    PaystackPop: {
      setup: (config: {
        key: string;
        email: string;
        amount: number;
        currency: string;
        ref: string;
        metadata?: {
          custom_fields: Array<{
            display_name: string;
            variable_name: string;
            value: string;
          }>;
        };
        callback: (response: { reference: string }) => void;
        onClose: () => void;
      }) => { openIframe: () => void };
    };
  }
}
