import type { Payment } from '../types';

const PAYSTACK_PUBLIC_KEY = 'pk_test_9721481771baa92fa5c2c78e1c94f2b61ecdd38b';

export interface VerificationResult {
  status: 'success' | 'failed' | 'pending';
  reference: string;
  amount: number;
  paidAt: string;
  channel: string;
  cardType?: string;
  last4?: string;
  bank?: string;
}

/**
 * Verify a Paystack transaction
 * In production, this should be done on your backend to protect your secret key
 */
export async function verifyTransaction(reference: string): Promise<VerificationResult | null> {

  // Always verify via backend Netlify function → Paystack.
  try {
    const res = await fetch('/api/verify-transaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reference }),
    });

    const data = await res.json();

    if (!data.status || !data.data) {
      return null;
    }

    const d = data.data;

    return {
      status: d.status === 'success' ? 'success' : d.status === 'failed' ? 'failed' : 'pending',
      reference: d.reference,
      amount: typeof d.amount === 'number' ? d.amount / 100 : 0,
      paidAt: d.paid_at,
      channel: d.channel,
      bank: d.authorization?.bank,
      cardType: d.authorization?.card_type,
      last4: d.authorization?.last4,
    };
  } catch (error) {
    console.error('Verification error:', error);
    return null;
  }
}

/**
 * Poll for payment verification
 */
export function pollForVerification(
  reference: string,
  onVerified: (result: VerificationResult) => void,
  onFailed: () => void,
  maxAttempts: number = 30,
  intervalMs: number = 5000
): () => void {
  let attempts = 0;
  let timeoutId: NodeJS.Timeout;

  const check = async () => {
    attempts++;
    
    try {
      const result = await verifyTransaction(reference);
      
      if (result?.status === 'success') {
        onVerified(result);
        return;
      } else if (result?.status === 'failed') {
        onFailed();
        return;
      }
      
      // Continue polling if still pending
      if (attempts < maxAttempts) {
        timeoutId = setTimeout(check, intervalMs);
      } else {
        onFailed();
      }
    } catch (error) {
      if (attempts < maxAttempts) {
        timeoutId = setTimeout(check, intervalMs);
      } else {
        onFailed();
      }
    }
  };

  // Start polling
  check();

  // Return cleanup function
  return () => {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
  };
}

/**
 * Store a pending payment for later verification
 */
export function storePendingPayment(payment: Payment): void {
  const pending = JSON.parse(localStorage.getItem('pendingPayments') || '[]');
  pending.push({
    ...payment,
    status: 'pending',
    createdAt: new Date().toISOString(),
  });
  localStorage.setItem('pendingPayments', JSON.stringify(pending));
}

/**
 * Mark a payment as verified
 */
export function markPaymentAsVerified(reference: string, verificationData: VerificationResult): Payment | null {
  // Remove from pending
  const pending = JSON.parse(localStorage.getItem('pendingPayments') || '[]');
  const paymentIndex = pending.findIndex((p: Payment) => p.reference === reference);
  
  if (paymentIndex === -1) return null;
  
  const payment = pending[paymentIndex];
  pending.splice(paymentIndex, 1);
  localStorage.setItem('pendingPayments', JSON.stringify(pending));
  
  // Update payment with verification data
  const verifiedPayment: Payment = {
    ...payment,
    status: 'completed',
    verifiedByPaystack: true,
    paidAt: verificationData.paidAt,
    paystackData: {
      channel: verificationData.channel,
      cardType: verificationData.cardType,
      last4: verificationData.last4,
      bank: verificationData.bank,
      paidAt: verificationData.paidAt,
    },
  };
  
  // Add to completed payments
  const completed = JSON.parse(localStorage.getItem('completedPayments') || '[]');
  completed.push(verifiedPayment);
  localStorage.setItem('completedPayments', JSON.stringify(completed));
  
  return verifiedPayment;
}

export function getPendingPayments(): Payment[] {
  return JSON.parse(localStorage.getItem('pendingPayments') || '[]');
}

export function getCompletedPayments(): Payment[] {
  return JSON.parse(localStorage.getItem('completedPayments') || '[]');
}

export function getPaymentsByCollection(collectionId: string): Payment[] {
  const completed = getCompletedPayments();
  return completed.filter((p: Payment) => p.collectionId === collectionId);
}

/**
 * Generate a unique Paystack reference
 */
export function generateReference(): string {
  return `TFS_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

export function getPublicKey(): string {
  return PAYSTACK_PUBLIC_KEY;
}
