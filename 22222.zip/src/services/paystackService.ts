const PAYSTACK_PUBLIC_KEY = 'pk_test_9721481771baa92fa5c2c78e1c94f2b61ecdd38b';

export interface PaystackBank {
  name: string;
  code: string;
}

export interface PaystackResponse {
  status: boolean;
  message: string;
  data?: any;
}

export interface VerificationResponse {
  status: boolean;
  message: string;
  data?: {
    status: 'success' | 'pending' | 'failed' | 'ongoing';
    reference: string;
    amount: number;
    gateway_response: string;
    paid_at: string | null;
    created_at: string;
    channel: string;
    currency: string;
    metadata: any;
    customer: {
      email: string;
      phone: string | null;
      first_name: string | null;
      last_name: string | null;
    };
  };
}

// List of Nigerian banks
export const NIGERIAN_BANKS: PaystackBank[] = [
  { name: 'Access Bank', code: '044' },
  { name: 'Citibank Nigeria', code: '023' },
  { name: 'Diamond Bank', code: '063' },
  { name: 'Ecobank Nigeria', code: '050' },
  { name: 'Fidelity Bank', code: '070' },
  { name: 'First Bank of Nigeria', code: '011' },
  { name: 'First City Monument Bank (FCMB)', code: '214' },
  { name: 'Guaranty Trust Bank (GTBank)', code: '058' },
  { name: 'Heritage Bank', code: '030' },
  { name: 'Keystone Bank', code: '082' },
  { name: 'Polaris Bank', code: '076' },
  { name: 'Providus Bank', code: '101' },
  { name: 'Stanbic IBTC Bank', code: '221' },
  { name: 'Standard Chartered Bank', code: '068' },
  { name: 'Sterling Bank', code: '232' },
  { name: 'SunTrust Bank', code: '100' },
  { name: 'Union Bank of Nigeria', code: '032' },
  { name: 'United Bank for Africa (UBA)', code: '033' },
  { name: 'Unity Bank', code: '215' },
  { name: 'Wema Bank', code: '035' },
  { name: 'Zenith Bank', code: '057' },
  { name: 'Kuda Bank', code: '50211' },
  { name: 'Rubies Bank', code: '125' },
  { name: 'VFD Microfinance Bank', code: '566' },
  { name: 'Palmpay', code: '999991' },
  { name: 'Opay', code: '999992' },
  { name: 'Moniepoint', code: '50515' },
];

// Initialize Paystack transaction
export const initializeTransaction = async (
  email: string,
  amount: number,
  metadata: any,
  callbackUrl?: string
): Promise<PaystackResponse> => {
  try {
    const response = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${PAYSTACK_PUBLIC_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        amount: amount * 100, // Convert to kobo
        metadata,
        callback_url: callbackUrl,
        channels: ['card', 'bank', 'ussd', 'qr', 'mobile_money'],
      }),
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Paystack initialization error:', error);
    return {
      status: false,
      message: 'Failed to initialize transaction',
    };
  }
};

// Verify Paystack transaction
export const verifyTransaction = async (reference: string): Promise<VerificationResponse> => {
  try {
    const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${PAYSTACK_PUBLIC_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Paystack verification error:', error);
    return {
      status: false,
      message: 'Failed to verify transaction',
    };
  }
};

// Poll for payment status
export const pollPaymentStatus = async (
  reference: string,
  onStatusUpdate: (status: string, data?: any) => void,
  maxAttempts: number = 60,
  interval: number = 5000
): Promise<void> => {
  let attempts = 0;

  const checkStatus = async () => {
    if (attempts >= maxAttempts) {
      onStatusUpdate('timeout');
      return;
    }

    try {
      const result = await verifyTransaction(reference);
      
      if (result.status && result.data) {
        const paymentStatus = result.data.status;
        
        if (paymentStatus === 'success') {
          onStatusUpdate('success', result.data);
          return;
        } else if (paymentStatus === 'failed') {
          onStatusUpdate('failed', result.data);
          return;
        }
      }

      attempts++;
      onStatusUpdate('pending', result.data);
      setTimeout(checkStatus, interval);
    } catch (error) {
      attempts++;
      onStatusUpdate('error');
      setTimeout(checkStatus, interval);
    }
  };

  checkStatus();
};

// Create bank transfer virtual account (for direct bank transfers)
export const createVirtualAccount = async (
  email: string,
  firstName: string,
  lastName: string,
  phone: string
): Promise<PaystackResponse> => {
  try {
    // First create a customer
    const customerResponse = await fetch('https://api.paystack.co/customer', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${PAYSTACK_PUBLIC_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        first_name: firstName,
        last_name: lastName,
        phone,
      }),
    });

    const customerData = await customerResponse.json();

    if (!customerData.status) {
      return customerData;
    }

    // Create dedicated virtual account
    const dvaResponse = await fetch('https://api.paystack.co/dedicated_account', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${PAYSTACK_PUBLIC_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        customer: customerData.data.customer_code,
        preferred_bank: 'wema-bank',
      }),
    });

    return await dvaResponse.json();
  } catch (error) {
    console.error('Virtual account creation error:', error);
    return {
      status: false,
      message: 'Failed to create virtual account',
    };
  }
};

// Load Paystack script dynamically
export const loadPaystackScript = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (window.PaystackPop) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://js.paystack.co/v2/inline.js';
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Paystack'));
    document.body.appendChild(script);
  });
};

// Pay with Paystack Popup
export const payWithPaystack = (
  email: string,
  amount: number,
  reference: string,
  metadata: any,
  onSuccess: (reference: string) => void,
  onClose: () => void
): void => {
  const handler = window.PaystackPop.setup({
    key: PAYSTACK_PUBLIC_KEY,
    email,
    amount: amount * 100,
    currency: 'NGN',
    ref: reference,
    metadata,
    onClose: () => {
      onClose();
    },
    callback: (response: { reference: string }) => {
      onSuccess(response.reference);
    },
  });

  handler.openIframe();
};

// PaystackPop is declared in types.ts
