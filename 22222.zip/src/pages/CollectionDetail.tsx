import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Copy, 
  Download, 
  Users, 
  TrendingUp,
  GraduationCap,
  Phone,
  Mail,
  CheckCircle,
  ExternalLink,
  Share2,
  Printer,
  Search
} from 'lucide-react';
import type { User, Collection } from '../types';

interface CollectionDetailProps {
  user: User;
  collections: Collection[];
  onUpdateCollection: (collection: Collection) => void;
}

export default function CollectionDetail({ collections }: CollectionDetailProps) {
  const { id } = useParams<{ id: string }>();
  const [searchTerm, setSearchTerm] = useState('');
  
  const collection = collections.find(c => c.id === id);

  if (!collection) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Collection Not Found</h2>
          <Link to="/dashboard" className="text-purple-600 hover:underline">
            Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const filteredMembers = collection.paidMembers.filter(member =>
    member.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.regNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const copyLink = () => {
    navigator.clipboard.writeText(collection.link);
    alert('Link copied to clipboard!');
  };

  const getCurrencySymbol = () => {
    const symbols: Record<string, string> = {
      NGN: '₦',
      USD: '$',
      GBP: '£',
      EUR: '€'
    };
    return symbols[collection.currency] || '₦';
  };

  const progress = collection.targetAmount 
    ? Math.min((collection.currentAmount / collection.targetAmount) * 100, 100)
    : 0;

  const exportToCSV = () => {
    const headers = ['Full Name', 'Registration Number', 'Phone', 'Email', 'Amount', 'Date Paid', 'Transaction Ref'];
    const rows = collection.paidMembers.map(member => [
      member.fullName,
      member.regNumber,
      member.phone,
      member.email,
      member.amount,
      new Date(member.paidAt).toLocaleDateString(),
      member.transactionRef
    ]);
    
    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${collection.title.replace(/\s+/g, '_')}_paid_members.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/dashboard" className="flex items-center text-gray-600 hover:text-gray-900 mb-4">
            <ArrowLeft className="h-5 w-5 mr-1" />
            Back to Dashboard
          </Link>
          <div className="flex flex-col md:flex-row md:items-start md:justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-2">
                <span className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium capitalize">
                  {collection.type} Amount
                </span>
                <span className="text-gray-500 text-sm">
                  Created {new Date(collection.createdAt).toLocaleDateString()}
                </span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900">{collection.title}</h1>
              <p className="text-gray-600 mt-2">{collection.description}</p>
            </div>
            <div className="flex items-center space-x-2 mt-4 md:mt-0">
              <button
                onClick={copyLink}
                className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <Copy className="h-4 w-4" />
                <span>Copy Link</span>
              </button>
              <Link
                to={`/contribute/${collection.id}`}
                target="_blank"
                className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <ExternalLink className="h-4 w-4" />
                <span>View Page</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Collected</p>
                <p className="text-2xl font-bold text-gray-900">
                  {getCurrencySymbol()}{collection.currentAmount.toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Contributors</p>
                <p className="text-2xl font-bold text-gray-900">{collection.paidMembers.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          {collection.targetAmount && (
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">Target Progress</p>
                  <p className="text-2xl font-bold text-gray-900">{progress.toFixed(1)}%</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </div>
          )}

          {collection.amount && (
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 text-sm">Fixed Amount</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {getCurrencySymbol()}{collection.amount.toLocaleString()}
                  </p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-orange-600" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Progress Bar for Target */}
        {collection.targetAmount && (
          <div className="bg-white rounded-xl p-6 shadow-sm mb-8">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">Target: {getCurrencySymbol()}{collection.targetAmount.toLocaleString()}</span>
              <span className="text-gray-900 font-semibold">
                {getCurrencySymbol()}{collection.currentAmount.toLocaleString()} raised
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-purple-600 to-purple-400 rounded-full h-3 transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Share Section */}
        <div className="bg-white rounded-xl p-6 shadow-sm mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Share Collection</h3>
          <div className="flex flex-wrap gap-3">
            <a
              href={`https://wa.me/?text=${encodeURIComponent(`Hi! Please pay for: ${collection.title}. Click here: ${collection.link}`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
            >
              <Share2 className="h-4 w-4" />
              <span>WhatsApp</span>
            </a>
            <a
              href={`mailto:?subject=Payment for ${collection.title}&body=Hi! Please make your payment here: ${collection.link}`}
              className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
            >
              <Mail className="h-4 w-4" />
              <span>Email</span>
            </a>
            <a
              href={`sms:?body=${encodeURIComponent(`Hi! Please pay for: ${collection.title}. Click here: ${collection.link}`)}`}
              className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <Phone className="h-4 w-4" />
              <span>SMS</span>
            </a>
          </div>
        </div>

        {/* Paid Members List */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Paid Members</h3>
                <p className="text-gray-500 text-sm">
                  {collection.paidMembers.length} student{collection.paidMembers.length !== 1 ? 's' : ''} have paid
                </p>
              </div>
              <div className="flex items-center space-x-3 mt-4 md:mt-0">
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search by name or reg no..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>
                <button
                  onClick={exportToCSV}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Download className="h-4 w-4" />
                  <span>Export CSV</span>
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Printer className="h-4 w-4" />
                  <span>Print</span>
                </button>
              </div>
            </div>
          </div>

          {filteredMembers.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-gray-400" />
              </div>
              <h4 className="text-lg font-medium text-gray-900 mb-2">
                {searchTerm ? 'No members found' : 'No payments yet'}
              </h4>
              <p className="text-gray-500">
                {searchTerm 
                  ? 'Try adjusting your search terms' 
                  : 'Share your collection link to start receiving payments'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">S/N</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Full Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reg Number</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date Paid</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredMembers.map((member, index) => (
                    <tr key={member.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-500">{index + 1}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                            <GraduationCap className="h-4 w-4 text-purple-600" />
                          </div>
                          <span className="font-medium text-gray-900">{member.fullName}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-mono text-gray-600">{member.regNumber}</span>
                      </td>
                      <td className="px-6 py-4 text-gray-600">{member.phone}</td>
                      <td className="px-6 py-4 font-semibold text-gray-900">
                        {getCurrencySymbol()}{member.amount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-gray-500 text-sm">
                        {new Date(member.paidAt).toLocaleDateString('en-NG', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric'
                        })}
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-mono text-xs text-gray-500">{member.transactionRef}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Collection Link Card */}
        <div className="bg-gradient-to-r from-purple-900 to-indigo-900 rounded-xl p-6 mt-8 text-white">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h3 className="font-bold mb-1">Collection Link</h3>
              <p className="text-purple-200 text-sm">Share this link with your classmates</p>
            </div>
            <div className="flex items-center space-x-2 mt-4 md:mt-0">
              <input
                type="text"
                value={collection.link}
                readOnly
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-sm flex-1 md:w-96"
              />
              <button
                onClick={copyLink}
                className="px-4 py-2 bg-white text-purple-900 rounded-lg font-medium hover:bg-purple-100 transition-colors"
              >
                Copy
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
