import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Film, 
  Plus, 
  Wallet, 
  Users, 
  TrendingUp, 
  Calendar,
  Copy,
  Trash2,
  ExternalLink,
  ChevronRight,
  Search,
  Filter,
  GraduationCap,
  Building2,
  Clock,
  AlertCircle
} from 'lucide-react';
import type { User, Collection, Transaction, Payment } from '../types';
import { getPendingPayments, getCompletedPayments } from '../services/paystackVerification';

interface DashboardProps {
  user: User;
  collections: Collection[];
  transactions: Transaction[];
  onDeleteCollection: (id: string) => void;
}

export default function Dashboard({ user, collections, transactions, onDeleteCollection }: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'fixed' | 'target' | 'open'>('all');
  const [pendingPayments, setPendingPayments] = useState<Payment[]>([]);
  const [completedPayments, setCompletedPayments] = useState<Payment[]>([]);

  // Load payments from localStorage
  useEffect(() => {
    setPendingPayments(getPendingPayments());
    setCompletedPayments(getCompletedPayments());
  }, []);

  // Calculate stats
  const totalCollected = completedPayments.reduce((sum, p) => sum + p.amount, 0);
  const pendingAmount = pendingPayments.reduce((sum, p) => sum + p.amount, 0);
  const totalContributors = new Set(completedPayments.map(p => p.payerRegNumber)).size;

  const filteredCollections = collections.filter(collection => {
    const matchesSearch = collection.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || collection.type === filterType;
    return matchesSearch && matchesType;
  });

  const copyLink = (link: string) => {
    navigator.clipboard.writeText(link);
    alert('Link copied to clipboard!');
  };

  const getCurrencySymbol = (currency: string) => {
    const symbols: Record<string, string> = {
      NGN: '₦',
      USD: '$',
      GBP: '£',
      EUR: '€'
    };
    return symbols[currency] || '₦';
  };

  const getStatusColor = (type: string) => {
    switch (type) {
      case 'fixed': return 'bg-blue-100 text-blue-800';
      case 'target': return 'bg-green-100 text-green-800';
      case 'open': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const confirmPaymentReceived = (paymentId: string) => {
    if (window.confirm('Have you received this payment in your bank account?')) {
      // Update payment status in localStorage
      const allPayments = JSON.parse(localStorage.getItem('payments') || '[]');
      const updatedPayments = allPayments.map((p: Payment) => 
        p.id === paymentId ? { ...p, status: 'completed', paidAt: new Date().toISOString() } : p
      );
      localStorage.setItem('payments', JSON.stringify(updatedPayments));
      
      // Refresh the lists
      setPendingPayments(getPendingPayments());
      setCompletedPayments(getCompletedPayments());
      
      alert('Payment confirmed successfully!');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-purple-900 via-purple-800 to-indigo-900 rounded-2xl p-6 mb-8 text-white">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-2">
                <Film className="h-6 w-6" />
                <span className="text-purple-200">200LV Theater & Film Studies</span>
              </div>
              <h1 className="text-2xl font-bold">Welcome back, {user.fullName}</h1>
              <p className="text-purple-200 mt-1">Reg No: {user.regNumber}</p>
            </div>
            <div className="mt-4 md:mt-0 flex space-x-3">
              <Link 
                to="/settings/bank"
                className="inline-flex items-center space-x-2 bg-white/20 text-white px-4 py-3 rounded-xl font-semibold hover:bg-white/30 transition-colors"
              >
                <Building2 className="h-5 w-5" />
                <span>Bank Settings</span>
              </Link>
              <Link 
                to="/create"
                className="inline-flex items-center space-x-2 bg-white text-purple-900 px-6 py-3 rounded-xl font-semibold hover:bg-purple-100 transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>Create New Collection</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Collections</p>
                <p className="text-2xl font-bold text-gray-900">{collections.length}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Wallet className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Total Earnings</p>
                <p className="text-2xl font-bold text-green-600">₦{totalCollected.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Pending Verification</p>
                <p className="text-2xl font-bold text-orange-600">{pendingPayments.length}</p>
                {pendingPayments.length > 0 && (
                  <p className="text-sm text-orange-500">₦{pendingAmount.toLocaleString()}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm">Contributors</p>
                <p className="text-2xl font-bold text-gray-900">{totalContributors}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Pending Verification Section */}
        {pendingPayments.length > 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                <h2 className="text-lg font-semibold">Pending Verification</h2>
              </div>
              <span className="text-sm text-gray-500">
                {pendingPayments.length} payment{pendingPayments.length > 1 ? 's' : ''} awaiting confirmation
              </span>
            </div>
            <div className="space-y-3">
              {pendingPayments.slice(0, 3).map((payment) => (
                <div key={payment.id} className="flex items-center justify-between p-4 bg-orange-50 rounded-xl">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                      <Clock className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{payment.payerName}</p>
                      <p className="text-sm text-gray-500">{payment.payerRegNumber}</p>
                      <p className="text-xs text-gray-400">{payment.payerPhone}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">₦{payment.amount.toLocaleString()}</p>
                    <p className="text-xs text-orange-500 mb-2">Awaiting verification</p>
                    <button
                      onClick={() => confirmPaymentReceived(payment.id)}
                      className="text-xs bg-green-600 text-white px-3 py-1 rounded-full hover:bg-green-700 transition-colors"
                    >
                      Confirm Received
                    </button>
                  </div>
                </div>
              ))}
              {pendingPayments.length > 3 && (
                <p className="text-center text-sm text-gray-500">
                  +{pendingPayments.length - 3} more pending
                </p>
              )}
            </div>
          </div>
        )}

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search collections..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="all">All Types</option>
              <option value="fixed">Fixed</option>
              <option value="target">Target</option>
              <option value="open">Open</option>
            </select>
          </div>
        </div>

        {/* Collections List */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900">Your Collections</h2>
          
          {filteredCollections.length === 0 ? (
            <div className="bg-white rounded-xl p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Wallet className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No collections yet</h3>
              <p className="text-gray-500 mb-6">Create your first payment collection to get started</p>
              <Link 
                to="/create"
                className="inline-flex items-center space-x-2 bg-purple-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-purple-700 transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>Create Collection</span>
              </Link>
            </div>
          ) : (
            filteredCollections.map((collection) => (
              <div key={collection.id} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(collection.type)}`}>
                        {collection.type}
                      </span>
                      <span className="text-gray-400 text-sm flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {new Date(collection.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900">{collection.title}</h3>
                    <p className="text-gray-600 text-sm mt-1 line-clamp-2">{collection.description}</p>
                    
                    <div className="flex items-center space-x-6 mt-4">
                      <div>
                        <p className="text-gray-500 text-xs">Amount</p>
                        <p className="font-semibold">
                          {collection.type === 'fixed' && collection.amount 
                            ? `${getCurrencySymbol(collection.currency)}${collection.amount.toLocaleString()}`
                            : 'Variable'}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs">Collected</p>
                        <p className="font-semibold text-green-600">
                          {getCurrencySymbol(collection.currency)}{collection.currentAmount.toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs">Contributors</p>
                        <p className="font-semibold">{collection.paidMembers.length}</p>
                      </div>
                      {collection.targetAmount && (
                        <div>
                          <p className="text-gray-500 text-xs">Target</p>
                          <p className="font-semibold">
                            {getCurrencySymbol(collection.currency)}{collection.targetAmount.toLocaleString()}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 mt-4 md:mt-0">
                    <button
                      onClick={() => copyLink(collection.link)}
                      className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                      title="Copy link"
                    >
                      <Copy className="h-5 w-5" />
                    </button>
                    <Link
                      to={`/contribute/${collection.id}`}
                      target="_blank"
                      className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                      title="Preview"
                    >
                      <ExternalLink className="h-5 w-5" />
                    </Link>
                    <Link
                      to={`/collection/${collection.id}`}
                      className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                      title="View details"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </Link>
                    <button
                      onClick={() => {
                        if (confirm('Are you sure you want to delete this collection?')) {
                          onDeleteCollection(collection.id);
                        }
                      }}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                {/* Progress bar for target collections */}
                {collection.targetAmount && (
                  <div className="mt-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-500">
                        {Math.min((collection.currentAmount / collection.targetAmount) * 100, 100).toFixed(1)}% of target
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-purple-600 rounded-full h-2 transition-all"
                        style={{ width: `${Math.min((collection.currentAmount / collection.targetAmount) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Recent Transactions */}
        {transactions.length > 0 && (
          <div className="mt-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Payments</h2>
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reg Number</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Collection</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {transactions.slice(0, 10).map((transaction) => (
                      <tr key={transaction.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                              <GraduationCap className="h-4 w-4 text-purple-600" />
                            </div>
                            <span className="font-medium text-gray-900">{transaction.fullName}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{transaction.regNumber}</td>
                        <td className="px-6 py-4 text-gray-600">{transaction.collectionTitle}</td>
                        <td className="px-6 py-4 font-semibold text-gray-900">
                          {getCurrencySymbol(transaction.currency)}{transaction.amount.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 text-gray-500 text-sm">
                          {new Date(transaction.paidAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            transaction.status === 'success' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {transaction.status === 'success' ? 'Paid' : 'Pending'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
