import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Film, 
  User, 
  Phone, 
  Mail, 
  GraduationCap,
  Lock,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Wallet
} from 'lucide-react';
import type { Collection, Transaction, BankAccount } from '../types';
import PaystackCheckout from '../components/checkout/PaystackCheckout';

interface ContributeProps {
  collections: Collection[];
  onPaymentComplete: (transaction: Transaction) => void;
}

export default function Contribute({ collections, onPaymentComplete }: ContributeProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [collection, setCollection] = useState<Collection | null>(null);
  const [hostBankAccount, setHostBankAccount] = useState<BankAccount | null>(null);
  const [amount, setAmount] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    regNumber: '',
    phone: '',
    email: ''
  });
  const [showCheckout, setShowCheckout] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [transactionRef, setTransactionRef] = useState('');

  useEffect(() => {
    if (id) {
      const found = collections.find(c => c.id === id);
      if (found) {
        setCollection(found);
        if (found.type === 'fixed' && found.amount) {
          setAmount(found.amount.toString());
        }
        
        // Load host's bank account details
        if (found.repId) {
          const savedAccounts = localStorage.getItem(`bankAccounts_${found.repId}`);
          if (savedAccounts) {
            const accounts = JSON.parse(savedAccounts);
            if (accounts.length > 0) {
              setHostBankAccount(accounts[0]); // Use first account as default
            }
          }
        }
      }
    }
  }, [id, collections]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const getCurrencySymbol = () => {
    const symbols: Record<string, string> = {
      NGN: '₦',
      USD: '$',
      GBP: '£',
      EUR: '€'
    };
    return symbols[collection?.currency || 'NGN'];
  };

  const validateForm = () => {
    if (!formData.fullName.trim()) return 'Full name is required';
    if (!formData.regNumber.trim()) return 'Registration number is required';
    if (!formData.email.trim()) return 'Email is required';
    if (!formData.phone.trim()) return 'Phone number is required';
    if (!amount || parseFloat(amount) <= 0) return 'Please enter a valid amount';
    return null;
  };

  const handleProceedToPayment = () => {
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }
    setError('');
    setShowCheckout(true);
  };

  const handlePaymentSuccess = async (reference: string, paystackData: any) => {
    if (!collection) return;
    
    setTransactionRef(reference);
    setIsVerifying(true);

    // Verify the payment with Paystack API via Netlify Function
    try {
      const response = await fetch('/api/verify-transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reference })
      });
      
      const verification = await response.json();
      
      if (verification.status && verification.data?.status === 'success') {
        const transaction: Transaction = {
          id: Date.now().toString(),
          collectionId: collection.id,
          collectionTitle: collection.title,
          fullName: formData.fullName,
          regNumber: formData.regNumber,
          phone: formData.phone,
          email: formData.email,
          amount: parseFloat(amount),
          currency: collection.currency,
          status: 'success',
          paymentMethod: paystackData?.channel || 'card',
          transactionRef: reference,
          paidAt: new Date().toISOString()
        };

        onPaymentComplete(transaction);
        setIsVerifying(false);
        setShowCheckout(false);
        setSuccess(true);
        
        setTimeout(() => {
          navigate('/payment-success', { 
            state: { 
              transactionRef: reference,
              amount: parseFloat(amount),
              currency: collection.currency,
              collectionTitle: collection.title
            }
          });
        }, 1500);
      } else {
        setError('Payment verification failed. Please contact support.');
        setIsVerifying(false);
      }
    } catch (err) {
      setError('Error verifying payment. Please contact support.');
      setIsVerifying(false);
    }
  };

  const handlePaymentPending = (reference: string) => {
    if (!collection) return;
    
    // For bank transfers, create a pending transaction
    const transaction: Transaction = {
      id: Date.now().toString(),
      collectionId: collection.id,
      collectionTitle: collection.title,
      fullName: formData.fullName,
      regNumber: formData.regNumber,
      phone: formData.phone,
      email: formData.email,
      amount: parseFloat(amount),
      currency: collection.currency,
      status: 'pending',
      paymentMethod: 'bank_transfer',
      transactionRef: reference,
      paidAt: new Date().toISOString()
    };

    onPaymentComplete(transaction);
  };

  if (!collection) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-violet-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Payment Submitted!</h2>
          <p className="text-gray-600 mb-4">
            Your payment is being processed. You will receive a confirmation once it's verified.
          </p>
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <p className="text-sm text-gray-600">Transaction Reference</p>
            <p className="font-mono font-semibold text-gray-900">{transactionRef}</p>
          </div>
          <p className="text-sm text-gray-500">Redirecting to success page...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-purple-600 text-white py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <Film className="w-8 h-8" />
            <span className="text-xl font-semibold">200LV Theater & Film Studies</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{collection.title}</h1>
          <p className="text-white/80">Organized by {collection.repName}</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-5 gap-8">
          {/* Left Column - Form */}
          <div className="md:col-span-3">
            <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
                <User className="w-5 h-5 text-violet-600" />
                Your Details
              </h2>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              )}

              <form className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      placeholder="Enter your full name"
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Registration Number <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <GraduationCap className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      name="regNumber"
                      value={formData.regNumber}
                      onChange={handleInputChange}
                      placeholder="e.g., 2021/123456"
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="your.email@example.com"
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="08012345678"
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>

                {collection.type !== 'fixed' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Amount ({getCurrencySymbol()}) <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Wallet className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="Enter amount"
                        min="100"
                        className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                        required
                      />
                    </div>
                    {collection.type === 'target' && collection.targetAmount && (
                      <p className="text-sm text-gray-500 mt-2">
                        Target: {getCurrencySymbol()}{collection.targetAmount.toLocaleString()}
                      </p>
                    )}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleProceedToPayment}
                  className="w-full py-4 bg-violet-600 text-white rounded-xl font-semibold text-lg hover:bg-violet-700 transition-colors flex items-center justify-center gap-2"
                >
                  Proceed to Payment
                  <ArrowRight className="w-5 h-5" />
                </button>
              </form>

              <div className="mt-6 flex items-center justify-center gap-2 text-sm text-gray-500">
                <Lock className="w-4 h-4" />
                <span>Secured by Paystack 256-bit SSL encryption</span>
              </div>
            </div>
          </div>

          {/* Right Column - Summary */}
          <div className="md:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-8">
              <h3 className="font-semibold text-gray-900 mb-4">Payment Summary</h3>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Collection</span>
                  <span className="font-medium text-gray-900">{collection.title}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Type</span>
                  <span className="font-medium text-gray-900 capitalize">{collection.type}</span>
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Amount to Pay</span>
                  <span className="text-2xl font-bold text-violet-600">
                    {getCurrencySymbol()}{parseFloat(amount || '0').toLocaleString()}
                  </span>
                </div>
              </div>

              {collection.type === 'target' && (
                <div className="mt-6 p-4 bg-violet-50 rounded-xl">
                  <p className="text-sm text-violet-800 mb-2">Progress</p>
                  <div className="w-full bg-violet-200 rounded-full h-2">
                    <div 
                      className="bg-violet-600 h-2 rounded-full transition-all"
                      style={{ 
                        width: `${Math.min(100, (collection.currentAmount / (collection.targetAmount || 1)) * 100)}%` 
                      }}
                    />
                  </div>
                  <p className="text-xs text-violet-600 mt-2">
                    {getCurrencySymbol()}{collection.currentAmount.toLocaleString()} of {getCurrencySymbol()}{collection.targetAmount?.toLocaleString()}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Paystack Checkout Modal */}
      {showCheckout && collection && (
        <PaystackCheckout
          isOpen={showCheckout}
          onClose={() => setShowCheckout(false)}
          amount={parseFloat(amount)}
          email={formData.email}
          phone={formData.phone}
          metadata={{
            fullName: formData.fullName,
            regNumber: formData.regNumber,
            collectionId: collection.id,
            collectionTitle: collection.title,
          }}
          hostBankDetails={hostBankAccount ? {
            bankName: hostBankAccount.bankName,
            accountNumber: hostBankAccount.accountNumber,
            accountName: hostBankAccount.accountName,
          } : null}
          onSuccess={handlePaymentSuccess}
          onPending={handlePaymentPending}
        />
      )}

      {/* Verification Overlay */}
      {isVerifying && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl p-8 text-center max-w-sm mx-4">
            <div className="animate-spin w-12 h-12 border-4 border-violet-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Verifying Payment</h3>
            <p className="text-gray-600">Please wait while we confirm your transaction...</p>
          </div>
        </div>
      )}
    </div>
  );
}
