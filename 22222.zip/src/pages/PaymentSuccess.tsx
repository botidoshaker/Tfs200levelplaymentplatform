import { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { CheckCircle, Film, ArrowLeft, Download, Share2 } from 'lucide-react';

interface PaymentState {
  transactionRef: string;
  amount: number;
  currency: string;
  collectionTitle: string;
}

export default function PaymentSuccess() {
  const location = useLocation();
  const [paymentData, setPaymentData] = useState<PaymentState | null>(null);

  useEffect(() => {
    const state = location.state as PaymentState;
    if (state) {
      setPaymentData(state);
    }
  }, [location.state]);

  if (!paymentData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-600">No payment information found.</p>
          <Link to="/" className="text-purple-600 hover:underline mt-4 inline-block">
            Go to Home
          </Link>
        </div>
      </div>
    );
  }

  const getCurrencySymbol = () => {
    const symbols: Record<string, string> = {
      NGN: '₦',
      USD: '$',
      GBP: '£',
      EUR: '€'
    };
    return symbols[paymentData.currency] || '₦';
  };

  const formatDate = () => {
    return new Date().toLocaleDateString('en-NG', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-lg mx-auto">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Success Header */}
          <div className="bg-gradient-to-br from-green-500 to-green-600 p-8 text-center text-white">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-10 w-10" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Payment Successful!</h1>
            <p className="text-green-100">Your transaction has been completed</p>
          </div>

          {/* Receipt Details */}
          <div className="p-8">
            <div className="text-center mb-8">
              <p className="text-gray-500 text-sm mb-1">Amount Paid</p>
              <p className="text-4xl font-bold text-gray-900">
                {getCurrencySymbol()}{paymentData.amount.toLocaleString()}
              </p>
            </div>

            <div className="space-y-4 border-t border-b border-gray-100 py-6 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-500">Transaction Reference</span>
                <span className="font-mono font-medium">{paymentData.transactionRef}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Payment For</span>
                <span className="font-medium text-right max-w-[60%]">{paymentData.collectionTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Date & Time</span>
                <span className="font-medium">{formatDate()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Status</span>
                <span className="text-green-600 font-medium">Completed</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Payment Method</span>
                <span className="font-medium">Paystack</span>
              </div>
            </div>

            {/* Powered By */}
            <div className="bg-purple-50 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-center space-x-2 text-purple-800">
                <Film className="h-5 w-5" />
                <span className="font-semibold">200LV Theater & Film Studies</span>
              </div>
              <p className="text-center text-purple-600 text-sm mt-1">
                Powered by Judexbeast TFS200LV
              </p>
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <button 
                onClick={() => window.print()}
                className="w-full flex items-center justify-center space-x-2 bg-purple-600 text-white py-3 rounded-xl font-semibold hover:bg-purple-700 transition-colors"
              >
                <Download className="h-5 w-5" />
                <span>Download Receipt</span>
              </button>
              
              <button 
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: 'Payment Receipt',
                      text: `I just paid ${getCurrencySymbol()}${paymentData.amount} for ${paymentData.collectionTitle}`,
                    });
                  }
                }}
                className="w-full flex items-center justify-center space-x-2 bg-gray-100 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
              >
                <Share2 className="h-5 w-5" />
                <span>Share Receipt</span>
              </button>

              <Link 
                to="/"
                className="w-full flex items-center justify-center space-x-2 border border-gray-300 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>Back to Home</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        <p className="text-center text-gray-500 text-sm mt-6">
          A confirmation email has been sent to your registered email address.
        </p>
      </div>
    </div>
  );
}
