import { Link } from 'react-router-dom';
import { 
  Film, 
  GraduationCap, 
  Shield, 
  QrCode, 
  Users, 
  CreditCard,
  ArrowRight,
  Play
} from 'lucide-react';
import { User } from '../types';

interface HomeProps {
  user: User | null;
}

export default function Home({ user }: HomeProps) {
  const features = [
    {
      icon: CreditCard,
      title: 'Class Payments',
      description: 'Collect dues, fees, and contributions from classmates easily'
    },
    {
      icon: QrCode,
      title: 'QR Code Payments',
      description: 'Share payment links via QR codes for quick access'
    },
    {
      icon: Shield,
      title: 'Secure Transactions',
      description: 'Powered by Paystack with bank-grade security'
    },
    {
      icon: Users,
      title: 'Track Payments',
      description: 'See who has paid with full names and registration numbers'
    }
  ];

  const stats = [
    { label: 'Active Students', value: '50+' },
    { label: 'Collections Created', value: '100+' },
    { label: 'Success Rate', value: '99.9%' },
    { label: 'Transaction Fee', value: '0%' }
  ];

  const steps = [
    {
      step: '1',
      title: 'Create Payment',
      description: 'Set up a collection for class dues, event fees, or contributions'
    },
    {
      step: '2',
      title: 'Share Link',
      description: 'Send the payment link to classmates via WhatsApp, email, or SMS'
    },
    {
      step: '3',
      title: 'Track Payments',
      description: 'Monitor who has paid with their full name and registration number'
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-8">
              <Film className="h-5 w-5 text-purple-300" />
              <span className="text-sm font-medium">200LV Theater & Film Studies</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight">
              Class Payment Platform
              <span className="block text-purple-300">Made Simple</span>
            </h1>
            
            <p className="text-xl text-purple-100 mb-10 max-w-2xl mx-auto">
              Collect class dues, event fees, and contributions seamlessly. 
              Track payments with full names and registration numbers.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              {user ? (
                <>
                  <Link 
                    to="/create"
                    className="w-full sm:w-auto bg-white text-purple-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-purple-100 transition-all flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
                  >
                    <span>Create Payment</span>
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                  <Link 
                    to="/dashboard"
                    className="w-full sm:w-auto bg-purple-700/50 text-white border border-white/30 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-purple-700 transition-all"
                  >
                    View Dashboard
                  </Link>
                </>
              ) : (
                <>
                  <Link 
                    to="/register"
                    className="w-full sm:w-auto bg-white text-purple-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-purple-100 transition-all flex items-center justify-center space-x-2 shadow-lg hover:shadow-xl"
                  >
                    <span>Get Started</span>
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                  <Link 
                    to="/login"
                    className="w-full sm:w-auto bg-purple-700/50 text-white border border-white/30 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-purple-700 transition-all"
                  >
                    Sign In
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
        
        {/* Stats Bar */}
        <div className="relative border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl md:text-4xl font-bold">{stat.value}</div>
                  <div className="text-purple-200 text-sm mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need for Class Payments
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Simplified payment collection designed specifically for 200LV Theater and Film Studies students
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center mb-6">
                  <feature.icon className="h-7 w-7 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Three simple steps to start collecting payments from your classmates
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-purple-50 p-8 rounded-2xl text-center">
                  <div className="w-16 h-16 bg-purple-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                    {step.step}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="h-8 w-8 text-gray-300" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Payment Methods */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Multiple Payment Options
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Your classmates can pay using their preferred method
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-800 p-8 rounded-2xl text-center">
              <CreditCard className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Card Payment</h3>
              <p className="text-gray-400">Pay with Mastercard, Visa, or Verve</p>
            </div>
            <div className="bg-gray-800 p-8 rounded-2xl text-center">
              <QrCode className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Bank Transfer</h3>
              <p className="text-gray-400">Direct transfer to designated account</p>
            </div>
            <div className="bg-gray-800 p-8 rounded-2xl text-center">
              <Play className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">USSD</h3>
              <p className="text-gray-400">Pay using USSD code on any phone</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-purple-900 to-indigo-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <GraduationCap className="h-16 w-16 mx-auto mb-6 text-purple-300" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Collecting Payments?
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Join other class reps and course representatives using our platform
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            {user ? (
              <Link 
                to="/create"
                className="w-full sm:w-auto bg-white text-purple-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-purple-100 transition-all"
              >
                Create Your First Payment
              </Link>
            ) : (
              <>
                <Link 
                  to="/register"
                  className="w-full sm:w-auto bg-white text-purple-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-purple-100 transition-all"
                >
                  Register Now
                </Link>
                <Link 
                  to="/login"
                  className="w-full sm:w-auto bg-purple-700 text-white border border-white/30 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-purple-600 transition-all"
                >
                  Sign In
                </Link>
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
