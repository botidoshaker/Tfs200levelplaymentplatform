import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Film, 
  Target, 
  Wallet, 
  Plus, 
  ArrowLeft, 
  Check,
  Calendar,
  FileText,
  DollarSign,
  Hash
} from 'lucide-react';
import { User, Collection } from '../types';

interface CreateCollectionProps {
  user: User;
  onCollectionCreated: (collection: Collection) => void;
}

const currencies = [
  { code: 'NGN', symbol: '₦', name: 'Nigerian Naira' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'EUR', symbol: '€', name: 'Euro' }
];

export default function CreateCollection({ user, onCollectionCreated }: CreateCollectionProps) {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [collectionType, setCollectionType] = useState<'fixed' | 'target' | 'open' | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    amount: '',
    targetAmount: '',
    currency: 'NGN',
    expiryDate: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [createdCollection, setCreatedCollection] = useState<Collection | null>(null);

  const handleTypeSelect = (type: 'fixed' | 'target' | 'open') => {
    setCollectionType(type);
    setStep(2);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      const newCollection: Collection = {
        id: Date.now().toString(36) + Math.random().toString(36).substr(2),
        title: formData.title,
        description: formData.description,
        type: collectionType!,
        amount: collectionType === 'fixed' ? parseFloat(formData.amount) : undefined,
        targetAmount: collectionType === 'target' ? parseFloat(formData.targetAmount) : undefined,
        currentAmount: 0,
        currency: formData.currency,
        repName: user.fullName,
        repId: user.id,
        expiryDate: formData.expiryDate,
        createdAt: new Date().toISOString(),
        link: '',
        paidMembers: []
      };

      // Generate link
      const baseUrl = window.location.origin;
      newCollection.link = `${baseUrl}/contribute/${newCollection.id}`;

      onCollectionCreated(newCollection);
      setCreatedCollection(newCollection);
      setStep(3);
      setIsLoading(false);
    }, 1500);
  };

  const copyLink = () => {
    if (createdCollection) {
      navigator.clipboard.writeText(createdCollection.link);
      alert('Link copied to clipboard!');
    }
  };

  const getCurrencySymbol = () => {
    return currencies.find(c => c.code === formData.currency)?.symbol || '₦';
  };

  const collectionTypes = [
    {
      type: 'fixed' as const,
      icon: Wallet,
      title: 'Fixed Amount',
      description: 'Everyone pays the same exact amount (e.g., ₦5,000 class dues)',
      example: 'Best for: Class dues, exam fees, uniform payments'
    },
    {
      type: 'target' as const,
      icon: Target,
      title: 'Target Amount',
      description: 'Set a fundraising goal and track progress (e.g., ₦200,000 for class trip)',
      example: 'Best for: Class trips, events, group projects'
    },
    {
      type: 'open' as const,
      icon: DollarSign,
      title: 'Open Amount',
      description: 'Contributors decide how much to give',
      example: 'Best for: Donations, gifts, voluntary contributions'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <button 
            onClick={() => step > 1 ? setStep(step - 1) : navigate('/dashboard')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="h-5 w-5 mr-1" />
            Back
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Create Collection</h1>
          <p className="text-gray-600 mt-2">Set up a new payment collection for your class</p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center">
            <div className={`flex items-center justify-center w-10 h-10 rounded-full ${step >= 1 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
              1
            </div>
            <div className={`flex-1 h-1 mx-4 ${step >= 2 ? 'bg-purple-600' : 'bg-gray-200'}`} />
            <div className={`flex items-center justify-center w-10 h-10 rounded-full ${step >= 2 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
              2
            </div>
            <div className={`flex-1 h-1 mx-4 ${step >= 3 ? 'bg-purple-600' : 'bg-gray-200'}`} />
            <div className={`flex items-center justify-center w-10 h-10 rounded-full ${step >= 3 ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
              3
            </div>
          </div>
          <div className="flex justify-between mt-2 text-sm text-gray-600">
            <span>Select Type</span>
            <span>Details</span>
            <span>Share</span>
          </div>
        </div>

        {/* Step 1: Select Type */}
        {step === 1 && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-6">What type of collection?</h2>
            <div className="space-y-4">
              {collectionTypes.map((type) => (
                <button
                  key={type.type}
                  onClick={() => handleTypeSelect(type.type)}
                  className="w-full p-6 border-2 border-gray-200 rounded-xl hover:border-purple-500 hover:bg-purple-50 transition-all text-left"
                >
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                      <type.icon className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">{type.title}</h3>
                      <p className="text-gray-600 mt-1">{type.description}</p>
                      <p className="text-sm text-purple-600 mt-2">{type.example}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Enter Details */}
        {step === 2 && collectionType && (
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <div className="flex items-center mb-6">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                {collectionType === 'fixed' && <Wallet className="h-5 w-5 text-purple-600" />}
                {collectionType === 'target' && <Target className="h-5 w-5 text-purple-600" />}
                {collectionType === 'open' && <DollarSign className="h-5 w-5 text-purple-600" />}
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  {collectionType === 'fixed' && 'Fixed Amount Collection'}
                  {collectionType === 'target' && 'Target Amount Collection'}
                  {collectionType === 'open' && 'Open Amount Collection'}
                </h2>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Collection Title
                </label>
                <div className="relative">
                  <FileText className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    name="title"
                    required
                    value={formData.title}
                    onChange={handleInputChange}
                    placeholder="e.g., 200LV Theater Class Dues"
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  name="description"
                  required
                  rows={3}
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Explain what this collection is for..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Currency
                  </label>
                  <select
                    name="currency"
                    value={formData.currency}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                  >
                    {currencies.map((currency) => (
                      <option key={currency.code} value={currency.code}>
                        {currency.code} ({currency.symbol})
                      </option>
                    ))}
                  </select>
                </div>

                {collectionType === 'fixed' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fixed Amount ({getCurrencySymbol()})
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-gray-500 font-medium">
                        {getCurrencySymbol()}
                      </span>
                      <input
                        type="number"
                        name="amount"
                        required
                        min="1"
                        value={formData.amount}
                        onChange={handleInputChange}
                        placeholder="5000"
                        className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>
                )}

                {collectionType === 'target' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Target Amount ({getCurrencySymbol()})
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-gray-500 font-medium">
                        {getCurrencySymbol()}
                      </span>
                      <input
                        type="number"
                        name="targetAmount"
                        required
                        min="1"
                        value={formData.targetAmount}
                        onChange={handleInputChange}
                        placeholder="200000"
                        className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>
                )}

                {collectionType === 'open' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Suggested Amount ({getCurrencySymbol()})
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-gray-500 font-medium">
                        {getCurrencySymbol()}
                      </span>
                      <input
                        type="number"
                        name="amount"
                        value={formData.amount}
                        onChange={handleInputChange}
                        placeholder="Optional"
                        className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Expiry Date (Optional)
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type="date"
                    name="expiryDate"
                    value={formData.expiryDate}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Film className="h-4 w-4" />
                  <span>Created by: <strong>{user.fullName}</strong></span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600 mt-1">
                  <Hash className="h-4 w-4" />
                  <span>Reg No: <strong>{user.regNumber}</strong></span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-purple-600 text-white py-4 rounded-xl font-semibold hover:bg-purple-700 transition-colors disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                    <span>Creating...</span>
                  </>
                ) : (
                  <>
                    <Plus className="h-5 w-5" />
                    <span>Create Collection</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* Step 3: Success & Share */}
        {step === 3 && createdCollection && (
          <div className="bg-white rounded-2xl shadow-sm p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="h-10 w-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Collection Created!</h2>
            <p className="text-gray-600 mb-8">
              Share this link with your classmates to start receiving payments
            </p>

            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <p className="text-sm text-gray-500 mb-2">Your collection link</p>
              <div className="flex items-center">
                <input
                  type="text"
                  value={createdCollection.link}
                  readOnly
                  className="flex-1 px-4 py-3 bg-white border border-gray-300 rounded-l-lg text-sm"
                />
                <button
                  onClick={copyLink}
                  className="px-4 py-3 bg-purple-600 text-white rounded-r-lg hover:bg-purple-700 transition-colors"
                >
                  Copy
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <a
                href={`https://wa.me/?text=Hi! Please pay for: ${encodeURIComponent(createdCollection.title)}. Click here: ${encodeURIComponent(createdCollection.link)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center space-x-2 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
              >
                <span>Share on WhatsApp</span>
              </a>
              <a
                href={`mailto:?subject=Payment for ${createdCollection.title}&body=Hi! Please make your payment here: ${createdCollection.link}`}
                className="flex items-center justify-center space-x-2 bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition-colors"
              >
                <span>Share via Email</span>
              </a>
            </div>

            <div className="flex justify-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Go to Dashboard
              </button>
              <button
                onClick={() => {
                  setStep(1);
                  setCollectionType(null);
                  setFormData({
                    title: '',
                    description: '',
                    amount: '',
                    targetAmount: '',
                    currency: 'NGN',
                    expiryDate: ''
                  });
                  setCreatedCollection(null);
                }}
                className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Create Another
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
