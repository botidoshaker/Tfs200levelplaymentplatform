import { useState, useEffect } from 'react';
import { 
  Building2, 
  Plus, 
  Trash2, 
  Star, 
  CheckCircle,
  AlertCircle,
  Loader2,
  ArrowLeft
} from 'lucide-react';
import type { User, BankAccount } from '../types';

const NIGERIAN_BANKS = [
  { name: 'Access Bank', code: '044' },
  { name: 'Citibank Nigeria', code: '023' },
  { name: 'Ecobank Nigeria', code: '050' },
  { name: 'Fidelity Bank', code: '070' },
  { name: 'First Bank of Nigeria', code: '011' },
  { name: 'First City Monument Bank (FCMB)', code: '214' },
  { name: 'Globus Bank', code: '00103' },
  { name: 'Guaranty Trust Bank (GTBank)', code: '058' },
  { name: 'Heritage Bank', code: '030' },
  { name: 'Keystone Bank', code: '082' },
  { name: 'Kuda Bank', code: '50211' },
  { name: 'Moniepoint Microfinance Bank', code: '50515' },
  { name: 'Opay', code: '999992' },
  { name: 'Palmpay', code: '999991' },
  { name: 'Parallex Bank', code: '526' },
  { name: 'Polaris Bank', code: '076' },
  { name: 'Providus Bank', code: '101' },
  { name: 'Stanbic IBTC Bank', code: '221' },
  { name: 'Standard Chartered Bank', code: '068' },
  { name: 'Sterling Bank', code: '232' },
  { name: 'SunTrust Bank', code: '100' },
  { name: 'Titan Trust Bank', code: '102' },
  { name: 'Union Bank of Nigeria', code: '032' },
  { name: 'United Bank for Africa (UBA)', code: '033' },
  { name: 'Unity Bank', code: '215' },
  { name: 'Wema Bank', code: '035' },
  { name: 'Zenith Bank', code: '057' },
];

interface BankSettingsProps {
  user: User;
}

export default function BankSettings({ user }: BankSettingsProps) {
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  
  const [formData, setFormData] = useState({
    bankName: '',
    bankCode: '',
    accountNumber: '',
    accountName: '',
  });
  const [isValidating, setIsValidating] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(`bankAccounts_${user.id}`);
    if (saved) {
      setAccounts(JSON.parse(saved));
    }
  }, [user.id]);

  useEffect(() => {
    localStorage.setItem(`bankAccounts_${user.id}`, JSON.stringify(accounts));
  }, [accounts, user.id]);

  // Auto-validate account when bank and number are entered
  useEffect(() => {
    const validateAccount = async () => {
      if (formData.bankCode && formData.accountNumber.length === 10) {
        setIsValidating(true);
        setFormData(prev => ({ ...prev, accountName: '' }));
        
        try {
          // Call Netlify function to verify account via Paystack
          const response = await fetch('/api/verify-bank', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              accountNumber: formData.accountNumber,
              bankCode: formData.bankCode
            })
          });
          
          const data = await response.json();
          
          if (data.status && data.account_name) {
            setFormData(prev => ({ ...prev, accountName: data.account_name }));
          } else {
            setMessage({ type: 'error', text: data.message || 'Could not verify account. Please check the details.' });
            setFormData(prev => ({ ...prev, accountName: '' }));
          }
        } catch (error) {
          console.error('Error verifying account:', error);
          setMessage({ type: 'error', text: 'Error verifying account. Please try again.' });
          setFormData(prev => ({ ...prev, accountName: '' }));
        } finally {
          setIsValidating(false);
        }
      }
    };

    const timeoutId = setTimeout(validateAccount, 500); // Debounce for 500ms
    return () => clearTimeout(timeoutId);
  }, [formData.bankCode, formData.accountNumber]);

  const handleBankChange = (bankName: string) => {
    const bank = NIGERIAN_BANKS.find(b => b.name === bankName);
    setFormData(prev => ({
      ...prev,
      bankName,
      bankCode: bank?.code || '',
      accountName: '',
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.accountName) {
      setMessage({ type: 'error', text: 'Please wait for account validation' });
      return;
    }

    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newAccount: BankAccount = {
      id: `acc_${Date.now()}`,
      userId: user.id,
      bankName: formData.bankName,
      bankCode: formData.bankCode,
      accountNumber: formData.accountNumber,
      accountName: formData.accountName,
      isDefault: accounts.length === 0, // First account is default
      createdAt: new Date().toISOString(),
    };

    setAccounts(prev => [...prev, newAccount]);
    setFormData({ bankName: '', bankCode: '', accountNumber: '', accountName: '' });
    setShowAddForm(false);
    setMessage({ type: 'success', text: 'Bank account added successfully!' });
    setIsLoading(false);

    setTimeout(() => setMessage({ type: '', text: '' }), 3000);
  };

  const setDefaultAccount = (id: string) => {
    setAccounts(prev => prev.map(acc => ({
      ...acc,
      isDefault: acc.id === id,
    })));
    setMessage({ type: 'success', text: 'Default account updated' });
    setTimeout(() => setMessage({ type: '', text: '' }), 3000);
  };

  const deleteAccount = (id: string) => {
    if (confirm('Are you sure you want to delete this account?')) {
      setAccounts(prev => {
        const filtered = prev.filter(acc => acc.id !== id);
        // If we deleted the default, set the first remaining as default
        if (filtered.length > 0 && !filtered.find(acc => acc.isDefault)) {
          filtered[0].isDefault = true;
        }
        return filtered;
      });
      setMessage({ type: 'success', text: 'Account deleted' });
      setTimeout(() => setMessage({ type: '', text: '' }), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Back Button */}
        <button 
          onClick={() => window.history.back()}
          className="flex items-center space-x-2 text-gray-600 hover:text-purple-600 mb-6"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Dashboard</span>
        </button>

        {/* Header */}
        <div className="bg-gradient-to-r from-purple-900 via-purple-800 to-indigo-900 text-white rounded-2xl p-6 mb-6">
          <div className="flex items-center space-x-3">
            <div className="bg-white/20 p-3 rounded-xl">
              <Building2 className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Bank Account Settings</h1>
              <p className="text-purple-200">Manage your payout accounts for direct transfers</p>
            </div>
          </div>
        </div>

        {/* Message */}
        {message.text && (
          <div className={`mb-6 p-4 rounded-xl flex items-center space-x-2 ${
            message.type === 'success' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-red-100 text-red-800'
          }`}>
            {message.type === 'success' ? (
              <CheckCircle className="h-5 w-5" />
            ) : (
              <AlertCircle className="h-5 w-5" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Add Account Button */}
        {!showAddForm && (
          <button
            onClick={() => setShowAddForm(true)}
            className="w-full mb-6 p-6 border-2 border-dashed border-purple-300 rounded-xl text-purple-600 hover:border-purple-500 hover:bg-purple-50 transition-colors flex items-center justify-center space-x-2"
          >
            <Plus className="h-5 w-5" />
            <span className="font-medium">Add Bank Account</span>
          </button>
        )}

        {/* Add Account Form */}
        {showAddForm && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Add New Account</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Bank
                </label>
                <select
                  required
                  value={formData.bankName}
                  onChange={(e) => handleBankChange(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Select a bank</option>
                  {NIGERIAN_BANKS.map(bank => (
                    <option key={bank.code} value={bank.name}>{bank.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Account Number
                </label>
                <input
                  type="text"
                  required
                  maxLength={10}
                  placeholder="Enter 10-digit account number"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, accountNumber: e.target.value.replace(/\D/g, '') }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Account Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    readOnly
                    value={formData.accountName}
                    placeholder={isValidating ? 'Validating...' : 'Account name will appear here'}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50"
                  />
                  {isValidating && (
                    <Loader2 className="absolute right-3 top-3 h-5 w-5 text-purple-600 animate-spin" />
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Account name is automatically validated
                </p>
              </div>

              <div className="flex space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isLoading || !formData.accountName}
                  className="flex-1 px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {isLoading && <Loader2 className="h-5 w-5 animate-spin" />}
                  <span>Add Account</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Accounts List */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-800">
            Your Accounts ({accounts.length})
          </h2>
          
          {accounts.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl shadow">
              <Building2 className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">No accounts yet</h3>
              <p className="text-gray-500">Add a bank account to receive direct transfers</p>
            </div>
          ) : (
            accounts.map(account => (
              <div 
                key={account.id}
                className={`bg-white rounded-xl shadow p-5 border-2 transition-colors ${
                  account.isDefault ? 'border-purple-500' : 'border-transparent'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="bg-purple-100 p-3 rounded-lg">
                      <Building2 className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{account.bankName}</h3>
                      <p className="text-lg font-medium text-gray-800 mt-1">
                        {account.accountNumber}
                      </p>
                      <p className="text-sm text-gray-500">{account.accountName}</p>
                      {account.isDefault && (
                        <span className="inline-flex items-center space-x-1 text-xs text-purple-600 bg-purple-50 px-2 py-1 rounded-full mt-2">
                          <Star className="h-3 w-3 fill-current" />
                          <span>Default</span>
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col space-y-2">
                    {!account.isDefault && (
                      <button
                        onClick={() => setDefaultAccount(account.id)}
                        className="p-2 text-gray-400 hover:text-purple-600 transition-colors"
                        title="Set as default"
                      >
                        <Star className="h-5 w-5" />
                      </button>
                    )}
                    <button
                      onClick={() => deleteAccount(account.id)}
                      className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      title="Delete account"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Info Box */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-4">
          <h4 className="font-medium text-blue-900 mb-2">How Direct Transfer Works</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Students can pay directly to your bank account</li>
            <li>• You'll see pending payments in your dashboard</li>
            <li>• Payment is verified automatically via Paystack</li>
            <li>• You receive the money directly in your bank</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
