export interface Host {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  course: string;
  department: string;
  contributionTitle: string;
  contributionDescription: string;
  targetAmount: number;
  deadline: string;
  createdAt: string;
  slug: string;
}

export interface Contribution {
  id: string;
  hostId: string;
  contributorName: string;
  contributorRegNumber: string;
  contributorEmail: string;
  contributorPhone: string;
  amount: number;
  paymentReference: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
}

export interface HostFormData {
  fullName: string;
  email: string;
  phone: string;
  course: string;
  department: string;
  contributionTitle: string;
  contributionDescription: string;
  targetAmount: string;
  deadline: string;
}

export interface ContributorFormData {
  fullName: string;
  regNumber: string;
  email: string;
  phone: string;
  amount: string;
}
