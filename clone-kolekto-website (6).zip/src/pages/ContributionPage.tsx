import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

interface Fund {
  id: string;
  slug: string;
  hostName: string;
  hostEmail: string;
  hostPhone: string;
  course: string;
  department: string;
  title: string;
  description: string;
  type: 'fixed' | 'flexible' | 'custom';
  fixedAmount?: number;
  targetAmount: number;
  deadline: string;
  bankName: string;
  bankAccountNumber: string;
  bankAccountName: string;
  createdAt: string;
  contributions: Contribution[];
}

interface Contribution {
  id: string;
  fullName: string;
  regNumber: string;
  email: string;
  phone: string;
  amount: number;
  paidAt: string;
  reference: string;
  transactionId?: string;
  status: 'pending' | 'verified' | 'rejected';
  transactionDate?: string;
  bankUsed?: string;
}

interface Props {
  getFundBySlug: (slug: string) => Fund | undefined;
  updateFund: (fund: Fund) => void;
}

export default function ContributionPage({ getFundBySlug, updateFund }: Props) {
  const { slug } = useParams<{ slug: string }>();
  const fund = slug ? getFundBySlug(slug) : undefined;
  
  const [step, setStep] = useState<'details' | 'bank-transfer' | 'success'>('details');
  const [formData, setFormData] = useState({
    fullName: '',
    regNumber: '',
    email: '',
    phone: '',
    amount: ''
  });
  const [errors, setErrors] = useState<Partial<Record<keyof typeof formData, string>>>({});
  const [copied, setCopied] = useState(false);
  const [countdown, setCountdown] = useState(3600);
  const [transactionRefInput, setTransactionRefInput] = useState('');
  const [paymentReference, setPaymentReference] = useState('');

  const totalRaised = fund?.contributions.reduce((sum, c) => c.status === 'verified' ? sum + c.amount : sum, 0) || 0;
  const progress = fund ? Math.min((totalRaised / fund.targetAmount) * 100, 100) : 0;

  useEffect(() => {
    if (step === 'bank-transfer' && countdown > 0) {
      const timer = setInterval(() => setCountdown(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [step, countdown]);

  const updateField = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = () => {
    const newErrors: Partial<Record<keyof typeof formData, string>> = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!formData.regNumber.trim()) newErrors.regNumber = 'Registration number is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Please enter a valid email';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.amount || Number(formData.amount) <= 0) newErrors.amount = 'Please enter a valid amount';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleTransferConfirmation = () => {
    if (!fund || !transactionRefInput.trim()) {
      alert('Please enter your transaction reference from your bank app');
      return;
    }

    const reference = 'TRF' + Date.now().toString().substring(5) + Math.random().toString(36).substring(2, 6).toUpperCase();

    const newContribution: Contribution = {
      id: Date.now().toString(),
      fullName: formData.fullName,
      regNumber: formData.regNumber,
      email: formData.email,
      phone: formData.phone,
      amount: Number(formData.amount),
      paidAt: new Date().toISOString(),
      reference: reference,
      transactionId: transactionRefInput,
      status: 'pending',
      transactionDate: new Date().toISOString(),
      bankUsed: fund.bankName
    };

    const updatedFund = {
      ...fund,
      contributions: [...fund.contributions, newContribution]
    };

    updateFund(updatedFund);
    setPaymentReference(reference);
    setStep('success');
  };

  const copyAccountNumber = () => {
    if (fund) {
      navigator.clipboard.writeText(fund.bankAccountNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!fund) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Fund Not Found</h1>
          <p className="text-gray-600 mb-6">This contribution page doesn't exist or has been removed.</p>
          <Link to="/" className="bg-violet-600 text-white px-6 py-3 rounded-full font-medium hover:bg-violet-700 transition">
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Submitted!</h1>
          <p className="text-gray-600 mb-6">
            Thank you for your contribution of {formatCurrency(Number(formData.amount))}.
          </p>
          <div className="bg-gray-50 rounded-xl p-4 mb-6">
            <p className="text-sm text-gray-500">Transaction Reference</p>
            <p className="text-lg font-mono font-semibold text-gray-900">{paymentReference}</p>
          </div>
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 mb-6">
            <p className="text-sm text-orange-800">
              ⏳ Your payment is pending verification. The organizer will confirm once they receive your transfer.
            </p>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
            <p className="text-sm text-blue-800">
              📱 Please share your payment receipt with the organizer for faster verification.
            </p>
          </div>
          <Link 
            to="/"
            className="block w-full bg-gradient-to-r from-violet-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all"
          >
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white border-b border-violet-100 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">C</span>
              </div>
              <span className="font-bold text-gray-900">ClassFund</span>
            </Link>
            <a 
              href={`/dashboard/${fund.id}`}
              className="text-violet-600 hover:text-violet-700 font-medium text-sm"
            >
              Host Dashboard →
            </a>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Fund Info Card */}
        <div className="bg-white rounded-2xl shadow-xl shadow-violet-500/10 border border-violet-100 overflow-hidden mb-6">
          <div className="bg-gradient-to-r from-violet-600 to-purple-600 px-6 py-4">
            <div className="flex items-center gap-2 text-violet-100 text-sm">
              <span>📚</span>
              <span>{fund.department} - {fund.course}</span>
            </div>
          </div>
          <div className="p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">{fund.title}</h1>
            <p className="text-gray-600 mb-6">{fund.description}</p>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-violet-100 rounded-full flex items-center justify-center">
                  <span className="text-violet-600 font-semibold">
                    {fund.hostName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">{fund.hostName}</p>
                  <p className="text-sm text-gray-500">Fund Organizer</p>
                </div>
              </div>
            </div>

            {/* Progress */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="flex justify-between items-end mb-2">
                <div>
                  <p className="text-sm text-gray-500">Raised so far (Verified)</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRaised)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">Target</p>
                  <p className="text-lg font-semibold text-violet-600">{formatCurrency(fund.targetAmount)}</p>
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-gradient-to-r from-violet-600 to-purple-600 h-3 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-500 mt-2">{progress.toFixed(0)}% funded</p>
            </div>
          </div>
        </div>

        {/* Payment Form Card */}
        <div className="bg-white rounded-2xl shadow-xl shadow-violet-500/10 border border-violet-100 p-6">
          {/* Step 1: Contributor Details */}
          {step === 'details' && (
            <div>
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-violet-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
                <h2 className="text-xl font-bold text-gray-900">Enter Your Details</h2>
                <p className="text-gray-600 text-sm">Fill in your information to contribute</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => updateField('fullName', e.target.value)}
                    placeholder="e.g., Chinedu Okonkwo"
                    className={`w-full px-4 py-3 rounded-xl border ${errors.fullName ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                  />
                  {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Registration Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.regNumber}
                    onChange={(e) => updateField('regNumber', e.target.value)}
                    placeholder="e.g., CG/2020/12345"
                    className={`w-full px-4 py-3 rounded-xl border ${errors.regNumber ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                  />
                  {errors.regNumber && <p className="text-red-500 text-sm mt-1">{errors.regNumber}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    placeholder="e.g., chinedu@unilag.edu.ng"
                    className={`w-full px-4 py-3 rounded-xl border ${errors.email ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                  />
                  {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    placeholder="e.g., 08012345678"
                    className={`w-full px-4 py-3 rounded-xl border ${errors.phone ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                  />
                  {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Contribution Amount <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">₦</span>
                    <input
                      type="number"
                      value={formData.amount}
                      onChange={(e) => updateField('amount', e.target.value)}
                      placeholder="Enter amount"
                      className={`w-full pl-8 pr-4 py-3 rounded-xl border ${errors.amount ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                    />
                  </div>
                  {errors.amount && <p className="text-red-500 text-sm mt-1">{errors.amount}</p>}
                </div>

                {/* Quick Amount Buttons */}
                {fund.type === 'flexible' && (
                  <div className="grid grid-cols-4 gap-2">
                    {[1000, 2000, 5000, 10000].map((amt) => (
                      <button
                        key={amt}
                        onClick={() => updateField('amount', amt.toString())}
                        className="py-2 border border-violet-200 rounded-lg text-sm font-medium text-violet-600 hover:bg-violet-50 transition"
                      >
                        ₦{amt.toLocaleString()}
                      </button>
                    ))}
                  </div>
                )}

                <button
                  onClick={() => {
                    if (validateForm()) setStep('bank-transfer');
                  }}
                  className="w-full bg-gradient-to-r from-violet-600 to-purple-600 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all mt-6"
                >
                  Continue to Payment
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Bank Transfer Page (SportyBet Style) */}
          {step === 'bank-transfer' && (
            <div>
              {/* Header */}
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={() => setStep('details')}
                  className="p-2 hover:bg-gray-100 rounded-lg transition"
                >
                  <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <h2 className="text-xl font-bold text-gray-900">Pay with Bank Transfer</h2>
              </div>

              {/* Amount Display */}
              <div className="text-center mb-6">
                <p className="text-sm text-gray-500 mb-2">Amount to Pay</p>
                <p className="text-4xl font-bold text-violet-600">₦{Number(formData.amount).toLocaleString()}.00</p>
              </div>

              {/* Bank Details Card */}
              <div className="bg-gradient-to-br from-violet-600 to-purple-700 rounded-2xl p-6 text-white mb-6">
                <p className="text-violet-200 text-sm mb-4">Transfer to the following account</p>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-violet-200 text-xs mb-1">Bank Name</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold">{fund.bankName}</span>
                    </div>
                  </div>

                  <div>
                    <p className="text-violet-200 text-xs mb-1">Account Number</p>
                    <div className="flex items-center gap-3">
                      <span className="text-3xl font-mono font-bold tracking-wider">{fund.bankAccountNumber}</span>
                      <button
                        onClick={copyAccountNumber}
                        className="bg-white/20 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-white/30 transition"
                      >
                        {copied ? '✓ Copied' : 'Copy'}
                      </button>
                    </div>
                  </div>

                  <div>
                    <p className="text-violet-200 text-xs mb-1">Account Name</p>
                    <span className="text-lg font-bold">{fund.bankAccountName}</span>
                  </div>
                </div>

                {/* Countdown Timer */}
                <div className="mt-6 pt-6 border-t border-white/20 text-center">
                  <p className="text-violet-200 text-sm mb-1">Order Expires in</p>
                  <p className="text-3xl font-mono font-bold">{formatTime(countdown)}</p>
                </div>
              </div>

              {/* Copy Account Number Button */}
              <button
                onClick={copyAccountNumber}
                className="w-full bg-gradient-to-r from-violet-600 to-purple-600 text-white py-4 rounded-xl font-semibold hover:shadow-lg transition-all mb-6"
              >
                {copied ? '✓ Account Number Copied!' : 'Copy Account Number'}
              </button>

              {/* Instructions */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                <p className="text-sm text-blue-800 font-medium mb-3">How to pay:</p>
                <ol className="text-sm text-blue-700 space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="bg-blue-200 text-blue-800 w-5 h-5 rounded-full flex items-center justify-center text-xs flex-shrink-0">1</span>
                    <span>Copy the account number above</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-blue-200 text-blue-800 w-5 h-5 rounded-full flex items-center justify-center text-xs flex-shrink-0">2</span>
                    <span>Open your banking app</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-blue-200 text-blue-800 w-5 h-5 rounded-full flex items-center justify-center text-xs flex-shrink-0">3</span>
                    <span>Transfer ₦{Number(formData.amount).toLocaleString()} to the account</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-blue-200 text-blue-800 w-5 h-5 rounded-full flex items-center justify-center text-xs flex-shrink-0">4</span>
                    <span>Enter your transaction reference below</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="bg-blue-200 text-blue-800 w-5 h-5 rounded-full flex items-center justify-center text-xs flex-shrink-0">5</span>
                    <span>Click "I've Made Payment"</span>
                  </li>
                </ol>
              </div>

              {/* Transaction Reference Input */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Transaction Reference <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={transactionRefInput}
                  onChange={(e) => setTransactionRefInput(e.target.value)}
                  placeholder="e.g., 0332oux96105"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition"
                />
                <p className="text-xs text-gray-500 mt-1">Find this in your bank app after transfer</p>
              </div>

              {/* Confirm Button */}
              <button
                onClick={handleTransferConfirmation}
                disabled={!transactionRefInput.trim()}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-xl font-semibold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed mb-3"
              >
                I've Made Payment
              </button>

              <button
                onClick={() => {
                  setStep('details');
                  setTransactionRefInput('');
                }}
                className="w-full border border-gray-200 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-50 transition"
              >
                Cancel
              </button>
            </div>
          )}

          {/* Security Badge */}
          <div className="bg-green-50 border border-green-200 rounded-xl p-3 mt-6">
            <p className="text-xs text-green-800 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              Secure payment - Host verifies after receiving transfer
            </p>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-6 flex items-center justify-center gap-4 text-sm text-gray-500">
          <span className="flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
            Secure Payment
          </span>
          <span className="flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
            </svg>
            Data Protected
          </span>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-violet-100 mt-12 py-8">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-gray-600 text-sm">
            © 2026 ClassFund. Made with ❤️ for students.
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Powered by jdxbst • Credits: Judexbeast • 🎓 website made to ease compilation stress
          </p>
        </div>
      </footer>
    </div>
  );
}
