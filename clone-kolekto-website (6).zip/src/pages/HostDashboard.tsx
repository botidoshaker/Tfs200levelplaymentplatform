import { Link, useParams } from 'react-router-dom';
import { Host, Contribution } from '../types';

interface Props {
  hosts: Host[];
  getContributionsByHost: (hostId: string) => Contribution[];
}

export default function HostDashboard({ hosts, getContributionsByHost }: Props) {
  const { hostId } = useParams<{ hostId: string }>();
  const host = hosts.find(h => h.id === hostId);

  if (!host) {
    return (
      <div className="min-h-screen bg-university-data flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Dashboard Not Found</h1>
          <p className="text-gray-600 mb-6">This dashboard doesn't exist or has been removed.</p>
          <Link to="/" className="bg-violet-600 text-white px-6 py-3 rounded-full font-medium hover:bg-violet-700 transition">
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  const hostContributions = getContributionsByHost(host.id);
  const totalRaised = hostContributions.reduce((sum, c) => sum + c.amount, 0);
  const progress = Math.min((totalRaised / host.targetAmount) * 100, 100);
  const remaining = host.targetAmount - totalRaised;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const shareUrl = `${window.location.origin}/contribute/${host.slug}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    alert('Link copied to clipboard!');
  };

  const exportData = () => {
    const csvContent = [
      ['Name', 'Reg Number', 'Email', 'Phone', 'Amount', 'Date', 'Reference'],
      ...hostContributions.map(c => [
        c.contributorName,
        c.contributorRegNumber,
        c.contributorEmail,
        c.contributorPhone,
        c.amount.toString(),
        new Date(c.createdAt).toLocaleDateString(),
        c.paymentReference
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${host.contributionTitle.replace(/\s+/g, '_')}_contributors.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-university-data relative">
      <div className="absolute inset-0 bg-gradient-to-br from-violet-900/85 via-purple-900/80 to-pink-900/75"></div>
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-violet-100 sticky top-0 z-50 relative">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">C</span>
              </div>
              <span className="font-bold text-gray-900">ClassFund</span>
            </Link>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600 hidden sm:block">Welcome, {host.fullName.split(' ')[0]}!</span>
              <Link to="/" className="text-violet-600 hover:text-violet-700 font-medium text-sm">
                Sign Out
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8 relative z-10">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
          <p className="text-white/80">Manage your contribution fund and track payments</p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-violet-500/10 border border-violet-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">💰</span>
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Raised</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalRaised)}</p>
              </div>
            </div>
            <div className="text-sm text-green-600">
              ↑ {progress.toFixed(0)}% of target
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-violet-500/10 border border-violet-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">👥</span>
              </div>
              <div>
                <p className="text-sm text-gray-500">Contributors</p>
                <p className="text-2xl font-bold text-gray-900">{hostContributions.length}</p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              People who have contributed
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-violet-500/10 border border-violet-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">🎯</span>
              </div>
              <div>
                <p className="text-sm text-gray-500">Target</p>
                <p className="text-2xl font-bold text-gray-900">{formatCurrency(host.targetAmount)}</p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              Goal amount
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg shadow-violet-500/10 border border-violet-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <span className="text-2xl">📅</span>
              </div>
              <div>
                <p className="text-sm text-gray-500">Deadline</p>
                <p className="text-lg font-bold text-gray-900">{formatDate(host.deadline)}</p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              {Math.max(0, Math.ceil((new Date(host.deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))} days remaining
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Progress Card */}
            <div className="bg-gradient-to-r from-violet-600 to-purple-600 rounded-2xl p-6 text-white">
              <h2 className="text-xl font-semibold mb-4">Fund Progress</h2>
              <div className="flex justify-between items-end mb-2">
                <div>
                  <p className="text-violet-200 text-sm">Raised</p>
                  <p className="text-3xl font-bold">{formatCurrency(totalRaised)}</p>
                </div>
                <div className="text-right">
                  <p className="text-violet-200 text-sm">Remaining</p>
                  <p className="text-xl font-semibold">{formatCurrency(Math.max(0, remaining))}</p>
                </div>
              </div>
              <div className="w-full bg-white/20 rounded-full h-4">
                <div 
                  className="bg-white h-4 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-violet-200 text-sm mt-2">{progress.toFixed(1)}% complete</p>
            </div>

            {/* Contributors Table */}
            <div className="bg-white rounded-2xl shadow-lg border border-violet-100 overflow-hidden">
              <div className="px-6 py-4 border-b border-violet-100 flex items-center justify-between">
                <h2 className="font-semibold text-gray-900">Contributors ({hostContributions.length})</h2>
                {hostContributions.length > 0 && (
                  <button
                    onClick={exportData}
                    className="text-sm text-violet-600 hover:text-violet-700 font-medium flex items-center gap-1"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Export CSV
                  </button>
                )}
              </div>
              {hostContributions.length === 0 ? (
                <div className="p-12 text-center">
                  <div className="text-6xl mb-4">🎉</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No contributions yet</h3>
                  <p className="text-gray-600 mb-4">Share your link to start receiving contributions</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reg Number</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {hostContributions.map((contribution) => (
                        <tr key={contribution.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center">
                                <span className="text-violet-600 text-sm font-medium">
                                  {contribution.contributorName.split(' ').map(n => n[0]).join('').slice(0, 1)}
                                </span>
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{contribution.contributorName}</p>
                                <p className="text-xs text-gray-500">{contribution.contributorEmail}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-600">{contribution.contributorRegNumber}</td>
                          <td className="px-6 py-4 font-semibold text-green-600">{formatCurrency(contribution.amount)}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{new Date(contribution.createdAt).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                              <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                              Paid
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Share Card */}
            <div className="bg-white rounded-2xl shadow-lg border border-violet-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Share Your Fund</h3>
              <p className="text-sm text-gray-600 mb-4">Share this link with your coursemates to collect contributions</p>
              <div className="flex gap-2 mb-4">
                <input
                  type="text"
                  value={shareUrl}
                  readOnly
                  className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-600 truncate"
                />
                <button
                  onClick={copyToClipboard}
                  className="px-4 py-2 bg-violet-600 text-white rounded-lg text-sm font-medium hover:bg-violet-700 transition"
                >
                  Copy
                </button>
              </div>
              <div className="flex gap-2">
                <a
                  href={`https://wa.me/?text=Please contribute to our class fund: ${shareUrl}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-green-500 text-white rounded-xl font-medium hover:bg-green-600 transition"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                  </svg>
                  WhatsApp
                </a>
                <a
                  href={`https://twitter.com/intent/tweet?text=Please contribute to our class fund: ${shareUrl}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-400 text-white rounded-xl font-medium hover:bg-blue-500 transition"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                  Twitter
                </a>
              </div>
            </div>

            {/* Fund Details */}
            <div className="bg-white rounded-2xl shadow-lg border border-violet-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Fund Details</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500">Fund Title</p>
                  <p className="font-medium text-gray-900">{host.contributionTitle}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Description</p>
                  <p className="text-gray-700 text-sm">{host.contributionDescription}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Course</p>
                  <p className="font-medium text-gray-900">{host.course} - {host.department}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Created</p>
                  <p className="font-medium text-gray-900">{formatDate(host.createdAt)}</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-2xl shadow-lg border border-violet-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <button
                  onClick={copyToClipboard}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 hover:border-violet-500 hover:bg-violet-50 transition"
                >
                  <span className="text-xl">🔗</span>
                  <span className="text-sm font-medium text-gray-700">Copy Fund Link</span>
                </button>
                <button
                  onClick={exportData}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 hover:border-violet-500 hover:bg-violet-50 transition"
                >
                  <span className="text-xl">📥</span>
                  <span className="text-sm font-medium text-gray-700">Download Contributors</span>
                </button>
                <Link
                  to={`/contribute/${host.slug}`}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 hover:border-violet-500 hover:bg-violet-50 transition"
                >
                  <span className="text-xl">👁️</span>
                  <span className="text-sm font-medium text-gray-700">View Public Page</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
