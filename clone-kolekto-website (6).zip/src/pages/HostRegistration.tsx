import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { HostFormData, Host } from '../types';

interface Props {
  onCreateHost: (data: Omit<Host, 'id' | 'slug' | 'createdAt'>) => Host;
}

export default function HostRegistration({ onCreateHost }: Props) {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<HostFormData>({
    fullName: '',
    email: '',
    phone: '',
    course: '',
    department: '',
    contributionTitle: '',
    contributionDescription: '',
    targetAmount: '',
    deadline: ''
  });
  const [errors, setErrors] = useState<Partial<Record<keyof HostFormData, string>>>({});

  const updateField = (field: keyof HostFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validateStep1 = () => {
    const newErrors: Partial<Record<keyof HostFormData, string>> = {};
    if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Please enter a valid email';
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.course.trim()) newErrors.course = 'Course is required';
    if (!formData.department.trim()) newErrors.department = 'Department is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Partial<Record<keyof HostFormData, string>> = {};
    if (!formData.contributionTitle.trim()) newErrors.contributionTitle = 'Title is required';
    if (!formData.contributionDescription.trim()) newErrors.contributionDescription = 'Description is required';
    if (!formData.targetAmount.trim()) newErrors.targetAmount = 'Target amount is required';
    else if (isNaN(Number(formData.targetAmount)) || Number(formData.targetAmount) <= 0) {
      newErrors.targetAmount = 'Please enter a valid amount';
    }
    if (!formData.deadline) newErrors.deadline = 'Deadline is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    const host = onCreateHost({
      fullName: formData.fullName,
      email: formData.email,
      phone: formData.phone,
      course: formData.course,
      department: formData.department,
      contributionTitle: formData.contributionTitle,
      contributionDescription: formData.contributionDescription,
      targetAmount: Number(formData.targetAmount),
      deadline: formData.deadline
    });
    navigate(`/contribute/${host.slug}`);
  };

  const InputField = ({ 
    label, 
    field, 
    type = 'text', 
    placeholder,
    required = false 
  }: { 
    label: string; 
    field: keyof HostFormData; 
    type?: string; 
    placeholder?: string;
    required?: boolean;
  }) => (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        value={formData[field]}
        onChange={(e) => updateField(field, e.target.value)}
        placeholder={placeholder}
        className={`w-full px-4 py-3 rounded-xl border ${errors[field] ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
      />
      {errors[field] && <p className="text-red-500 text-sm mt-1">{errors[field]}</p>}
    </div>
  );

  return (
    <div className="min-h-screen bg-university-library relative py-12">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/90 via-purple-900/85 to-violet-900/90"></div>
      <div className="max-w-2xl mx-auto px-4 relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-6">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Home
          </Link>
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-violet-600 to-purple-600 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-xl">C</span>
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              ClassFund
            </span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Create Your Fund</h1>
          <p className="text-white/80">Set up your contribution page in minutes</p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className={`flex items-center gap-2 ${step >= 1 ? 'text-violet-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${step >= 1 ? 'bg-violet-600 text-white' : 'bg-gray-200'}`}>
              1
            </div>
            <span className="text-sm font-medium">Your Details</span>
          </div>
          <div className={`w-12 h-0.5 ${step >= 2 ? 'bg-violet-600' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center gap-2 ${step >= 2 ? 'text-violet-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold ${step >= 2 ? 'bg-violet-600 text-white' : 'bg-gray-200'}`}>
              2
            </div>
            <span className="text-sm font-medium">Fund Details</span>
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-2xl shadow-xl shadow-violet-500/10 border border-violet-100 p-8">
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Personal Information</h2>
                <p className="text-gray-600 text-sm">Tell us about yourself so contributors know who's organizing.</p>
              </div>
              
              <InputField label="Full Name" field="fullName" placeholder="e.g., Chinedu Okonkwo" required />
              <InputField label="Email Address" field="email" type="email" placeholder="e.g., chinedu@unilag.edu.ng" required />
              <InputField label="Phone Number" field="phone" type="tel" placeholder="e.g., 08012345678" required />
              
              <div className="grid md:grid-cols-2 gap-4">
                <InputField label="Course" field="course" placeholder="e.g., Computer Science" required />
                <InputField label="Department" field="department" placeholder="e.g., Faculty of Science" required />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-2">Fund Information</h2>
                <p className="text-gray-600 text-sm">Describe what you're collecting funds for.</p>
              </div>
              
              <InputField label="Fund Title" field="contributionTitle" placeholder="e.g., Final Year Project Contribution" required />
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={formData.contributionDescription}
                  onChange={(e) => updateField('contributionDescription', e.target.value)}
                  placeholder="Describe what the funds will be used for..."
                  rows={4}
                  className={`w-full px-4 py-3 rounded-xl border ${errors.contributionDescription ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition resize-none`}
                />
                {errors.contributionDescription && <p className="text-red-500 text-sm mt-1">{errors.contributionDescription}</p>}
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Target Amount (₦) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={formData.targetAmount}
                    onChange={(e) => updateField('targetAmount', e.target.value)}
                    placeholder="e.g., 100000"
                    className={`w-full px-4 py-3 rounded-xl border ${errors.targetAmount ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                  />
                  {errors.targetAmount && <p className="text-red-500 text-sm mt-1">{errors.targetAmount}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Deadline <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => updateField('deadline', e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className={`w-full px-4 py-3 rounded-xl border ${errors.deadline ? 'border-red-500' : 'border-gray-200'} focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition`}
                  />
                  {errors.deadline && <p className="text-red-500 text-sm mt-1">{errors.deadline}</p>}
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
            {step === 1 ? (
              <button
                onClick={() => navigate('/')}
                className="text-gray-500 hover:text-gray-700 transition"
              >
                Cancel
              </button>
            ) : (
              <button
                onClick={() => setStep(1)}
                className="flex items-center gap-2 text-gray-500 hover:text-gray-700 transition"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back
              </button>
            )}
            <button
              onClick={handleNext}
              className="bg-gradient-to-r from-violet-600 to-purple-600 text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all flex items-center gap-2"
            >
              {step === 1 ? 'Continue' : 'Create Fund'}
              {step === 1 && (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Info Box */}
        <div className="mt-6 bg-violet-50 rounded-xl p-4 border border-violet-100">
          <div className="flex items-start gap-3">
            <span className="text-2xl">ℹ️</span>
            <div className="text-sm text-violet-700">
              <strong>What happens next?</strong>
              <p className="mt-1">After creating your fund, you'll get a unique link to share with your coursemates. They'll fill in their details and make payments directly through your page.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
