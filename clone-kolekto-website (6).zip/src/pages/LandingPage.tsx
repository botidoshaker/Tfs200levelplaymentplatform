import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-university-campus relative">
      <div className="absolute inset-0 bg-gradient-to-br from-violet-900/90 via-purple-900/85 to-indigo-900/90"></div>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-violet-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">C</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                ClassFund
              </span>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-600 hover:text-violet-600 transition">Features</a>
              <a href="#how-it-works" className="text-gray-600 hover:text-violet-600 transition">How It Works</a>
            </nav>
            <div className="flex items-center gap-4">
              <Link to="/register" className="text-violet-600 hover:text-violet-700 font-medium transition">
                Sign In
              </Link>
              <Link 
                to="/register" 
                className="bg-gradient-to-r from-violet-600 to-purple-600 text-white px-5 py-2.5 rounded-full font-medium hover:shadow-lg hover:shadow-violet-500/30 transition-all"
              >
                Create Fund
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Collect Contributions from{' '}
              <span className="bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                Coursemates
              </span>{' '}
              Made Easy
            </h1>
            <p className="text-lg sm:text-xl text-white/90 mb-10 max-w-2xl mx-auto">
              Create a payment link, share with your classmates, and track contributions in real-time. 
              Perfect for class projects, events, group gifts, and more.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link 
                to="/register" 
                className="w-full sm:w-auto bg-gradient-to-r from-violet-600 to-purple-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl hover:shadow-violet-500/30 transition-all"
              >
                Create Your Fund →
              </Link>
              <a 
                href="#how-it-works"
                className="w-full sm:w-auto border-2 border-violet-200 text-violet-700 px-8 py-4 rounded-full font-semibold text-lg hover:border-violet-600 hover:bg-violet-50 transition-all"
              >
                See How It Works
              </a>
            </div>
          </div>

          {/* Hero Image/Dashboard Preview - No fake numbers */}
          <div className="mt-16 relative">
            <div className="absolute inset-0 bg-gradient-to-t from-violet-50 via-transparent to-transparent z-10"></div>
            <div className="bg-white rounded-2xl shadow-2xl shadow-violet-500/20 border border-violet-100 overflow-hidden max-w-5xl mx-auto">
              <div className="bg-gradient-to-r from-violet-600 to-purple-600 px-6 py-4 flex items-center gap-2">
                <div className="w-3 h-3 bg-white/30 rounded-full"></div>
                <div className="w-3 h-3 bg-white/30 rounded-full"></div>
                <div className="w-3 h-3 bg-white/30 rounded-full"></div>
              </div>
              <div className="p-8 bg-gray-50">
                <div className="text-center py-12">
                  <div className="inline-flex items-center justify-center w-20 h-20 bg-violet-100 rounded-full mb-4">
                    <svg className="w-10 h-10 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Your Dashboard Will Appear Here</h3>
                  <p className="text-gray-600">Track total raised, contributors, and progress towards your goal</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gradient-to-br from-violet-50 via-white to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need to Collect Funds
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Simple, secure, and designed specifically for student groups and coursemates.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: '🔗',
                title: 'Personal Payment Link',
                description: 'Get a unique link to share with your coursemates via WhatsApp, email, or social media.'
              },
              {
                icon: '📝',
                title: 'Collect Details',
                description: 'Automatically gather names, registration numbers, and contact info from contributors.'
              },
              {
                icon: '💳',
                title: 'Secure Payments',
                description: 'Integrated with trusted payment processors for safe and reliable transactions.'
              },
              {
                icon: '📊',
                title: 'Real-time Tracking',
                description: 'See who has contributed, track progress towards your goal, and send reminders.'
              },
              {
                icon: '📱',
                title: 'Mobile Friendly',
                description: 'Works perfectly on all devices. Contributors can pay from their phones easily.'
              },
              {
                icon: '📥',
                title: 'Export Data',
                description: 'Download contributor lists and payment records for your records.'
              }
            ].map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-sm border border-violet-100 hover:shadow-lg hover:border-violet-200 transition-all">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              How ClassFund Works
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Get started in minutes and start collecting contributions today.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Create Your Fund',
                description: 'Register and set up your contribution page with your goal, deadline, and description.',
                color: 'from-violet-500 to-purple-500'
              },
              {
                step: '02',
                title: 'Share Your Link',
                description: 'Get your unique payment link and share it with your coursemates via any platform.',
                color: 'from-purple-500 to-pink-500'
              },
              {
                step: '03',
                title: 'Track & Collect',
                description: 'Watch contributions come in real-time and track who has paid from your dashboard.',
                color: 'from-pink-500 to-rose-500'
              }
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-2xl p-8 h-full border border-violet-100">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${item.color} text-white text-2xl font-bold mb-6`}>
                    {item.step}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
                {index < 2 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                    <svg className="w-8 h-8 text-violet-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-violet-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Ready to Start Collecting?
          </h2>
          <p className="text-xl text-violet-100 mb-10">
            Create your fund in under 5 minutes and start receiving contributions from your coursemates.
          </p>
          <Link 
            to="/register" 
            className="inline-flex items-center gap-2 bg-white text-violet-600 px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl transition-all"
          >
            Create Your Fund Now
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-violet-500 to-purple-500 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">C</span>
                </div>
                <span className="text-xl font-bold text-white">ClassFund</span>
              </div>
              <p className="text-sm">
                The easiest way for student groups to collect contributions and manage payments together.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#features" className="hover:text-white transition">Features</a></li>
                <li><a href="#how-it-works" className="hover:text-white transition">How It Works</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition">FAQs</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition">Refund Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm">&copy; {new Date().getFullYear()} ClassFund. All rights reserved.</p>
              <div className="flex flex-col md:flex-row items-center gap-2 text-sm flex-wrap justify-center">
                <p className="text-gray-500">
                  Powered by <span className="text-violet-400 font-semibold">jdxbst</span>
                </p>
                <span className="hidden md:inline text-gray-600">•</span>
                <p className="text-gray-500">
                  Credits: <span className="text-violet-400 font-semibold">Judexbeast</span>
                </p>
                <span className="hidden md:inline text-gray-600">•</span>
                <div className="flex items-center space-x-2">
                  <span className="text-lg">🎓</span>
                  <span className="text-gray-500">website made to easy compilation stress</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
