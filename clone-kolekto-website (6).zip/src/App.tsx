import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

// Types
interface Fund {
  id: string;
  slug: string;
  hostName: string;
  hostEmail: string;
  hostPhone: string;
  course: string;
  department: string;
  title: string;
  description: string;
  type: 'fixed' | 'flexible' | 'custom';
  fixedAmount?: number;
  targetAmount: number;
  deadline: string;
  bankName: string;
  bankAccountNumber: string;
  bankAccountName: string;
  createdAt: string;
  contributions: Contribution[];
  requiredFields: string[];
}

interface Contribution {
  id: string;
  fullName: string;
  regNumber: string;
  email: string;
  phone: string;
  amount: number;
  paidAt: string;
  reference: string;
  paystackReference?: string;
  status: 'pending' | 'verified' | 'rejected';
  transactionDate?: string;
  bankUsed?: string;
}

// Utility functions
const generateSlug = (title: string): string => {
  const baseSlug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  const uniqueId = Math.random().toString(36).substring(2, 7);
  return `${baseSlug}-${uniqueId}`;
};

const generateReference = (): string => {
  return 'CF' + Date.now().toString().substring(5) + Math.random().toString(36).substring(2, 6).toUpperCase();
};

const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN' }).format(amount);
};

const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-NG', { day: 'numeric', month: 'short', year: 'numeric' });
};

// Storage helpers
const getFunds = (): Fund[] => {
  const funds = localStorage.getItem('classfund_funds');
  return funds ? JSON.parse(funds) : [];
};

const saveFund = (fund: Fund): void => {
  const funds = getFunds();
  const existingIndex = funds.findIndex(f => f.id === fund.id);
  if (existingIndex >= 0) {
    funds[existingIndex] = fund;
  } else {
    funds.push(fund);
  }
  localStorage.setItem('classfund_funds', JSON.stringify(funds));
};

const getFundBySlug = (slug: string): Fund | undefined => {
  return getFunds().find(f => f.slug === slug);
};

const getFundById = (id: string): Fund | undefined => {
  return getFunds().find(f => f.id === id);
};

// Header Component
const Header: React.FC = () => {
  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-18">
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="w-11 h-11 bg-gradient-to-br from-violet-600 to-purple-700 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/30 group-hover:scale-105 transition-transform">
              <span className="text-white font-bold text-lg">C</span>
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-700 bg-clip-text text-transparent">ClassFund</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/dashboard" className="text-gray-600 hover:text-violet-600 font-medium transition-colors flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
              </svg>
              Dashboard
            </Link>
            <Link to="/create" className="text-gray-600 hover:text-violet-600 font-medium transition-colors flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Create Fund
            </Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link to="/create" className="bg-gradient-to-r from-violet-600 to-purple-700 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Create Fund
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

// Landing Page Component
const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section with University Background */}
      <section className="relative bg-gradient-to-br from-violet-600 via-purple-700 to-indigo-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img src="/images/university-bg-1.jpg" alt="University Campus" className="w-full h-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-br from-violet-600/90 via-purple-700/90 to-indigo-800/90"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <span className="text-2xl">🎓</span>
              <span className="text-sm font-medium">Trusted by Student Organizations</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Collect Contributions from<br/>Your Classmates
            </h1>
            <p className="text-xl text-violet-100 mb-10 max-w-2xl mx-auto leading-relaxed">
              Create a fund, share your link, and track contributions effortlessly. Perfect for class projects, events, and group expenses.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/create" className="bg-white text-violet-700 px-10 py-5 rounded-2xl font-semibold text-lg hover:shadow-2xl hover:shadow-white/20 transition-all hover:-translate-y-1">
                Create Your Fund
              </Link>
              <Link to="/dashboard" className="border-2 border-white text-white px-10 py-5 rounded-2xl font-semibold text-lg hover:bg-white hover:text-violet-700 transition-all hover:-translate-y-1">
                View Dashboard
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-gray-50 to-transparent"></div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-white relative">
        <div className="absolute inset-0 opacity-5">
          <img src="/images/university-pattern.png" alt="Pattern" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Three simple steps to collect contributions</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-10 elevated-card group">
              <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-violet-500/30">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <div className="inline-block bg-violet-100 text-violet-700 font-bold text-sm px-4 py-1 rounded-full mb-4">Step 1</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Create Fund</h3>
              <p className="text-gray-600 leading-relaxed">Set up your contribution fund with title, description, and target amount in minutes</p>
            </div>
            <div className="text-center p-10 elevated-card group">
              <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-violet-500/30">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
              </div>
              <div className="inline-block bg-violet-100 text-violet-700 font-bold text-sm px-4 py-1 rounded-full mb-4">Step 2</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Share Link</h3>
              <p className="text-gray-600 leading-relaxed">Share your unique link via WhatsApp, email, or social media with your classmates</p>
            </div>
            <div className="text-center p-10 elevated-card group">
              <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-lg shadow-violet-500/30">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="inline-block bg-violet-100 text-violet-700 font-bold text-sm px-4 py-1 rounded-full mb-4">Step 3</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Track Progress</h3>
              <p className="text-gray-600 leading-relaxed">Monitor contributions in real-time from your beautiful dashboard</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-gradient-to-br from-gray-50 to-violet-50 relative">
        <div className="absolute inset-0 opacity-5">
          <img src="/images/university-bg-3.jpg" alt="Students" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Powerful Features</h2>
            <p className="text-xl text-gray-600">Everything you need to collect contributions successfully</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '🎯', title: 'Fixed or Flexible Amounts', desc: 'Set a fixed contribution or let classmates choose their amount' },
              { icon: '📊', title: 'Real-time Tracking', desc: 'See contributions as they come in with live updates' },
              { icon: '📱', title: 'Mobile Friendly', desc: 'Works perfectly on all devices' },
              { icon: '🔗', title: 'Easy Sharing', desc: 'Share via WhatsApp, email, or copy link' },
              { icon: '📝', title: 'Contributor Details', desc: 'Collect name, reg number, email, and phone' },
              { icon: '💳', title: 'Secure Payments', desc: 'Paystack-powered secure payment processing' },
            ].map((feature, idx) => (
              <div key={idx} className="elevated-card p-8 group hover:shadow-2xl transition-all duration-300">
                <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">{feature.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/university-bg-2.jpg" alt="Graduation" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-violet-600/95 to-purple-700/95"></div>
        </div>
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-block mb-6">
            <span className="text-6xl">🎉</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Start Collecting?</h2>
          <p className="text-xl text-violet-100 mb-10 max-w-2xl mx-auto">Create your fund in minutes and start receiving contributions from your classmates.</p>
          <Link to="/create" className="bg-white text-violet-700 px-12 py-5 rounded-2xl font-semibold text-lg hover:shadow-2xl hover:shadow-white/20 transition-all hover:-translate-y-1 inline-block">
            Create Your Fund Now
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-violet-600 to-purple-700 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-xl">C</span>
                </div>
                <span className="text-2xl font-bold">ClassFund</span>
              </div>
              <p className="text-gray-400 leading-relaxed max-w-md">
                The easiest way for students to collect contributions for class projects, events, and group expenses.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
                <li><Link to="/create" className="text-gray-400 hover:text-white transition-colors">Create Fund</Link></li>
                <li><Link to="/dashboard" className="text-gray-400 hover:text-white transition-colors">Dashboard</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Support</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-400">© 2026 ClassFund. Made with ❤️ for students.</p>
              <div className="flex flex-col md:flex-row items-center gap-3 text-sm flex-wrap justify-center">
                <p className="text-gray-400">
                  Powered by <span className="text-violet-400 font-semibold">jdxbst</span>
                </p>
                <span className="text-gray-600">•</span>
                <p className="text-gray-400">
                  Credits: <span className="text-violet-400 font-semibold">Judexbeast</span>
                </p>
                <span className="text-gray-600">•</span>
                <div className="flex items-center space-x-2">
                  <span className="text-2xl">🎓</span>
                  <span className="text-gray-400">website made to easy compilation stress</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

// Create Fund Page - Type Selection
const CreateFundPage: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [fundType, setFundType] = useState<'fixed' | 'flexible' | 'custom'>('fixed');
  const [formData, setFormData] = useState({
    hostName: '',
    hostEmail: '',
    hostPhone: '',
    course: '',
    department: '',
    title: '',
    description: '',
    fixedAmount: '',
    targetAmount: '',
    deadline: '',
    bankName: '',
    bankAccountNumber: '',
    bankAccountName: '',
  });
  const [requiredFields, setRequiredFields] = useState<string[]>(['fullName', 'regNumber', 'phoneNumber']);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const availableFields = [
    { id: 'fullName', label: 'Full Name', icon: '👤' },
    { id: 'regNumber', label: 'Registration Number', icon: '📋' },
    { id: 'schoolEmail', label: 'School Email', icon: '📧' },
    { id: 'phoneNumber', label: 'Phone Number', icon: '📱' },
    { id: 'department', label: 'Department', icon: '🏛️' },
    { id: 'level', label: 'Level/Year', icon: '📚' },
    { id: 'matricNumber', label: 'Matric Number', icon: '' },
  ];

  const toggleField = (fieldId: string) => {
    if (requiredFields.includes(fieldId)) {
      if (requiredFields.length > 1) {
        setRequiredFields(requiredFields.filter(f => f !== fieldId));
      }
    } else {
      setRequiredFields([...requiredFields, fieldId]);
    }
  };

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.hostName.trim()) newErrors.hostName = 'Full name is required';
    if (!formData.hostEmail.trim()) newErrors.hostEmail = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.hostEmail)) newErrors.hostEmail = 'Invalid email format';
    if (!formData.hostPhone.trim()) newErrors.hostPhone = 'Phone number is required';
    if (!formData.course.trim()) newErrors.course = 'Course is required';
    if (!formData.department.trim()) newErrors.department = 'Department is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) newErrors.title = 'Fund title is required';
    if (!formData.description.trim()) newErrors.description = 'Description is required';
    if (!formData.targetAmount.trim()) newErrors.targetAmount = 'Target amount is required';
    else if (isNaN(Number(formData.targetAmount)) || Number(formData.targetAmount) <= 0) newErrors.targetAmount = 'Invalid amount';
    if (!formData.deadline) newErrors.deadline = 'Deadline is required';
    if (fundType === 'fixed' && !formData.fixedAmount.trim()) {
      newErrors.fixedAmount = 'Fixed amount is required';
    } else if (fundType === 'fixed' && (isNaN(Number(formData.fixedAmount)) || Number(formData.fixedAmount) <= 0)) {
      newErrors.fixedAmount = 'Invalid fixed amount';
    }
    if (!formData.bankName.trim()) newErrors.bankName = 'Bank name is required';
    if (!formData.bankAccountNumber.trim()) newErrors.bankAccountNumber = 'Account number is required';
    else if (!/^\d{10}$/.test(formData.bankAccountNumber.replace(/\s/g, ''))) newErrors.bankAccountNumber = 'Invalid account number (10 digits)';
    if (!formData.bankAccountName.trim()) newErrors.bankAccountName = 'Account name is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    } else if (step === 3) {
      setStep(4);
    }
  };

  const handleSubmit = () => {
    const fund: Fund = {
      id: Date.now().toString(),
      slug: generateSlug(formData.title),
      hostName: formData.hostName,
      hostEmail: formData.hostEmail,
      hostPhone: formData.hostPhone,
      course: formData.course,
      department: formData.department,
      title: formData.title,
      description: formData.description,
      type: fundType,
      fixedAmount: fundType === 'fixed' ? Number(formData.fixedAmount) : undefined,
      targetAmount: Number(formData.targetAmount),
      deadline: formData.deadline,
      bankName: formData.bankName,
      bankAccountNumber: formData.bankAccountNumber,
      bankAccountName: formData.bankAccountName,
      createdAt: new Date().toISOString(),
      contributions: [],
      requiredFields: requiredFields,
    };
    saveFund(fund);
    navigate(`/fund/${fund.id}/share`);
  };

  return (
    <div className="min-h-screen pb-20">
      <Header />
      <div className="relative">
        <div className="absolute inset-0 opacity-10">
          <img src="/images/university-bg-1.jpg" alt="University" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Progress Steps */}
          <div className="flex items-center justify-center mb-12">
            {[1, 2, 3, 4].map((s) => (
              <React.Fragment key={s}>
                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg shadow-lg ${step >= s ? 'bg-gradient-to-br from-violet-600 to-purple-700 text-white shadow-violet-500/30' : 'bg-gray-200 text-gray-500'}`}>
                  {s}
                </div>
                {s < 4 && <div className={`w-24 h-1.5 rounded-full ${step > s ? 'bg-gradient-to-r from-violet-600 to-purple-700' : 'bg-gray-200'}`} />}
              </React.Fragment>
            ))}
          </div>

          <div className="elevated-card p-10">
          {step === 1 && (
            <>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Host Information</h2>
              <p className="text-gray-600 mb-8">Enter your details to create your fund</p>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input
                    type="text"
                    value={formData.hostName}
                    onChange={(e) => setFormData({ ...formData, hostName: e.target.value })}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.hostName ? 'border-red-500' : 'border-gray-300'}`}
                    placeholder="Enter your full name"
                  />
                  {errors.hostName && <p className="text-red-500 text-sm mt-1">{errors.hostName}</p>}
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input
                      type="email"
                      value={formData.hostEmail}
                      onChange={(e) => setFormData({ ...formData, hostEmail: e.target.value })}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.hostEmail ? 'border-red-500' : 'border-gray-300'}`}
                      placeholder="your@email.com"
                    />
                    {errors.hostEmail && <p className="text-red-500 text-sm mt-1">{errors.hostEmail}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.hostPhone}
                      onChange={(e) => setFormData({ ...formData, hostPhone: e.target.value })}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.hostPhone ? 'border-red-500' : 'border-gray-300'}`}
                      placeholder="08012345678"
                    />
                    {errors.hostPhone && <p className="text-red-500 text-sm mt-1">{errors.hostPhone}</p>}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Course</label>
                    <input
                      type="text"
                      value={formData.course}
                      onChange={(e) => setFormData({ ...formData, course: e.target.value })}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.course ? 'border-red-500' : 'border-gray-300'}`}
                      placeholder="e.g., Computer Science"
                    />
                    {errors.course && <p className="text-red-500 text-sm mt-1">{errors.course}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
                    <input
                      type="text"
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.department ? 'border-red-500' : 'border-gray-300'}`}
                      placeholder="e.g., Faculty of Science"
                    />
                    {errors.department && <p className="text-red-500 text-sm mt-1">{errors.department}</p>}
                  </div>
                </div>

                <button onClick={handleNext} className="w-full bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all">
                  Continue
                </button>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Fund Details</h2>
              <p className="text-gray-600 mb-8">Set up your contribution fund</p>

              {/* Fund Type Selection */}
              <div className="mb-8">
                <label className="block text-sm font-medium text-gray-700 mb-4">Contribution Type</label>
                <div className="grid md:grid-cols-3 gap-4">
                  <button
                    onClick={() => setFundType('fixed')}
                    className={`p-4 border-2 rounded-xl text-left transition-all ${fundType === 'fixed' ? 'border-violet-600 bg-violet-50' : 'border-gray-200 hover:border-gray-300'}`}
                  >
                    <div className="font-semibold text-gray-900 mb-1">Fixed Amount</div>
                    <div className="text-sm text-gray-600">Everyone contributes the same amount</div>
                  </button>
                  <button
                    onClick={() => setFundType('flexible')}
                    className={`p-4 border-2 rounded-xl text-left transition-all ${fundType === 'flexible' ? 'border-violet-600 bg-violet-50' : 'border-gray-200 hover:border-gray-300'}`}
                  >
                    <div className="font-semibold text-gray-900 mb-1">Flexible Amount</div>
                    <div className="text-sm text-gray-600">Contributors choose their amount</div>
                  </button>
                  <button
                    onClick={() => setFundType('custom')}
                    className={`p-4 border-2 rounded-xl text-left transition-all ${fundType === 'custom' ? 'border-violet-600 bg-violet-50' : 'border-gray-200 hover:border-gray-300'}`}
                  >
                    <div className="font-semibold text-gray-900 mb-1">Custom</div>
                    <div className="text-sm text-gray-600">Set suggested amounts</div>
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Fund Title</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.title ? 'border-red-500' : 'border-gray-300'}`}
                    placeholder="e.g., Final Year Project Fund"
                  />
                  {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.description ? 'border-red-500' : 'border-gray-300'}`}
                    placeholder="Describe what this fund is for..."
                  />
                  {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
                </div>

                {fundType === 'fixed' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Fixed Contribution Amount (₦)</label>
                    <input
                      type="number"
                      value={formData.fixedAmount}
                      onChange={(e) => setFormData({ ...formData, fixedAmount: e.target.value })}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.fixedAmount ? 'border-red-500' : 'border-gray-300'}`}
                      placeholder="e.g., 5000"
                    />
                    {errors.fixedAmount && <p className="text-red-500 text-sm mt-1">{errors.fixedAmount}</p>}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Target Amount (₦)</label>
                  <input
                    type="number"
                    value={formData.targetAmount}
                    onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.targetAmount ? 'border-red-500' : 'border-gray-300'}`}
                    placeholder="e.g., 100000"
                  />
                  {errors.targetAmount && <p className="text-red-500 text-sm mt-1">{errors.targetAmount}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Deadline</label>
                  <input
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.deadline ? 'border-red-500' : 'border-gray-300'}`}
                  />
                  {errors.deadline && <p className="text-red-500 text-sm mt-1">{errors.deadline}</p>}
                </div>

                {/* Bank Account Details */}
                <div className="border-t border-gray-200 pt-6 mt-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Bank Account Details</h3>
                  <p className="text-sm text-gray-600 mb-6">Enter the bank account where contributions will be sent</p>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Name</label>
                      <input
                        type="text"
                        value={formData.bankName}
                        onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.bankName ? 'border-red-500' : 'border-gray-300'}`}
                        placeholder="e.g., Zenith Bank, GTBank, Access Bank"
                      />
                      {errors.bankName && <p className="text-red-500 text-sm mt-1">{errors.bankName}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Account Number</label>
                      <input
                        type="text"
                        value={formData.bankAccountNumber}
                        onChange={(e) => setFormData({ ...formData, bankAccountNumber: e.target.value })}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.bankAccountNumber ? 'border-red-500' : 'border-gray-300'}`}
                        placeholder="10-digit account number"
                        maxLength={10}
                      />
                      {errors.bankAccountNumber && <p className="text-red-500 text-sm mt-1">{errors.bankAccountNumber}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Account Name</label>
                      <input
                        type="text"
                        value={formData.bankAccountName}
                        onChange={(e) => setFormData({ ...formData, bankAccountName: e.target.value })}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.bankAccountName ? 'border-red-500' : 'border-gray-300'}`}
                        placeholder="Name on the bank account"
                      />
                      {errors.bankAccountName && <p className="text-red-500 text-sm mt-1">{errors.bankAccountName}</p>}
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button onClick={() => setStep(1)} className="flex-1 border border-gray-300 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all">
                    Back
                  </button>
                  <button onClick={handleNext} className="flex-1 bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all">
                    Continue
                  </button>
                </div>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Required Fields</h2>
              <p className="text-gray-600 mb-8">Select what information contributors must provide</p>

              <div className="mb-8">
                <p className="text-sm font-medium text-gray-700 mb-4">Select required fields for contributors:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableFields.map((field) => (
                    <button
                      key={field.id}
                      onClick={() => toggleField(field.id)}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${
                        requiredFields.includes(field.id)
                          ? 'border-violet-600 bg-violet-50 shadow-md'
                          : 'border-gray-200 bg-white hover:border-violet-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                          requiredFields.includes(field.id)
                            ? 'bg-violet-600 text-white'
                            : 'bg-gray-200 text-gray-400'
                        }`}>
                          {requiredFields.includes(field.id) && (
                            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          )}
                        </div>
                        <span className="text-2xl">{field.icon}</span>
                        <span className="font-medium text-gray-900">{field.label}</span>
                      </div>
                    </button>
                  ))}
                </div>
                <p className="text-sm text-gray-500 mt-4">
                  ✅ {requiredFields.length} field{requiredFields.length !== 1 ? 's' : ''} selected - Contributors must fill these before paying
                </p>
              </div>

              <div className="flex gap-4">
                <button onClick={() => setStep(2)} className="flex-1 border border-gray-300 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all">
                  Back
                </button>
                <button onClick={handleNext} className="flex-1 bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all">
                  Continue
                </button>
              </div>
            </>
          )}

          {step === 4 && (
            <>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Review & Create</h2>
              <p className="text-gray-600 mb-8">Review your fund details before creating</p>

              <div className="bg-gray-50 rounded-xl p-6 mb-8">
                <h3 className="font-semibold text-gray-900 mb-4">Fund Summary</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Title:</span>
                    <span className="font-medium text-gray-900">{formData.title}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Type:</span>
                    <span className="font-medium text-gray-900 capitalize">{fundType} amount</span>
                  </div>
                  {fundType === 'fixed' && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Fixed Amount:</span>
                      <span className="font-medium text-gray-900">₦{Number(formData.fixedAmount).toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Target:</span>
                    <span className="font-medium text-gray-900">₦{Number(formData.targetAmount).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Deadline:</span>
                    <span className="font-medium text-gray-900">{formatDate(formData.deadline)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Host:</span>
                    <span className="font-medium text-gray-900">{formData.hostName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Bank:</span>
                    <span className="font-medium text-gray-900">{formData.bankName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Account:</span>
                    <span className="font-medium text-gray-900">{formData.bankAccountNumber}</span>
                  </div>
                  <div className="pt-3 border-t">
                    <span className="text-gray-600">Required Fields:</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {requiredFields.map(fieldId => {
                        const field = availableFields.find(f => f.id === fieldId);
                        return (
                          <span key={fieldId} className="bg-violet-100 text-violet-700 text-xs px-3 py-1 rounded-full font-medium">
                            {field?.icon} {field?.label}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button onClick={() => setStep(3)} className="flex-1 border border-gray-300 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all">
                  Back
                </button>
                <button onClick={handleSubmit} className="flex-1 bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all">
                  Create Fund
                </button>
              </div>
            </>
          )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Share Fund Page
const ShareFundPage: React.FC = () => {
  const { fundId } = useParams<{ fundId: string }>();
  const navigate = useNavigate();
  const fund = getFundById(fundId || '');
  
  const [copied, setCopied] = useState(false);

  if (!fund) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Fund not found</h2>
          <button onClick={() => navigate('/')} className="text-violet-600 hover:underline">Go Home</button>
        </div>
      </div>
    );
  }

  const contributeUrl = `${window.location.origin}/contribute/${fund.slug}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(contributeUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareViaWhatsApp = () => {
    const message = `Hi! Please contribute to our class fund: ${fund.title}. Click here: ${contributeUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const shareViaEmail = () => {
    const subject = `Contribute to ${fund.title}`;
    const body = `Hi,\n\nPlease contribute to our class fund: ${fund.title}\n\nTarget: ₦${fund.targetAmount.toLocaleString()}\nDeadline: ${formatDate(fund.deadline)}\n\nClick here to contribute: ${contributeUrl}\n\nThank you!`;
    window.open(`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
  };

  const shareViaSMS = () => {
    const message = `Contribute to ${fund.title}: ${contributeUrl}`;
    window.open(`sms:?body=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="min-h-screen pb-20">
      <Header />
      <div className="relative">
        <div className="absolute inset-0 opacity-10">
          <img src="/images/university-bg-2.jpg" alt="Celebration" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-8 animate-fade-in">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-500/30">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Fund Created Successfully!</h1>
            <p className="text-gray-600">Your fund "{fund.title}" is ready to receive contributions</p>
          </div>

        {/* Bank Account Details Card */}
        <div className="bg-gradient-to-br from-violet-600 to-purple-700 rounded-2xl shadow-lg p-8 mb-8 text-white">
          <h2 className="text-xl font-semibold mb-6">Bank Account Details</h2>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                </svg>
              </div>
              <div>
                <p className="text-violet-200 text-sm">Bank Name</p>
                <p className="text-lg font-semibold">{fund.bankName}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div>
                <p className="text-violet-200 text-sm">Account Name</p>
                <p className="text-lg font-semibold">{fund.bankAccountName}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <p className="text-violet-200 text-sm">Account Number</p>
                <p className="text-lg font-semibold">{fund.bankAccountNumber}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Fund Link Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Contribution Link</h2>
          <div className="flex gap-2 mb-6">
            <input
              type="text"
              value={contributeUrl}
              readOnly
              className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-700"
            />
            <button
              onClick={handleCopy}
              className={`px-6 py-3 rounded-xl font-semibold transition-all ${copied ? 'bg-green-600 text-white' : 'bg-violet-600 text-white hover:bg-violet-700'}`}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>

          {/* Share Options */}
          <div className="border-t border-gray-100 pt-6">
            <h3 className="text-sm font-medium text-gray-700 mb-4">Share via</h3>
            <div className="grid grid-cols-3 gap-4">
              <button
                onClick={shareViaWhatsApp}
                className="flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-xl font-semibold hover:bg-green-600 transition-all"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                WhatsApp
              </button>
              <button
                onClick={shareViaEmail}
                className="flex items-center justify-center gap-2 bg-blue-500 text-white py-3 rounded-xl font-semibold hover:bg-blue-600 transition-all"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                Email
              </button>
              <button
                onClick={shareViaSMS}
                className="flex items-center justify-center gap-2 bg-orange-500 text-white py-3 rounded-xl font-semibold hover:bg-orange-600 transition-all"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                SMS
              </button>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-4">
          <button
            onClick={() => navigate(`/dashboard/${fund.id}`)}
            className="bg-white border border-gray-200 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all"
          >
            View Dashboard
          </button>
          <button
            onClick={() => window.open(contributeUrl, '_blank')}
            className="bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all"
          >
            Preview Contribution Page
          </button>
        </div>
        </div>
      </div>
    </div>
  );
};

// Contribute Page - Kolekto Style
const ContributePage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const fund = getFundBySlug(slug || '');

  const [step, setStep] = useState(1);
  const [showBankDetails, setShowBankDetails] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    regNumber: '',
    email: '',
    phone: '',
    amount: '',
    department: '',
    level: '',
    matricNumber: '',
    schoolEmail: '',
    transactionRef: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const fieldLabels: Record<string, string> = {
    fullName: 'Full Name',
    regNumber: 'Registration Number',
    schoolEmail: 'School Email',
    phoneNumber: 'Phone Number',
    department: 'Department',
    level: 'Level/Year',
    matricNumber: 'Matric Number',
  };

  const getFieldPlaceholder = (fieldId: string): string => {
    const placeholders: Record<string, string> = {
      fullName: 'Enter your full name',
      regNumber: 'e.g., CSC/2020/001',
      schoolEmail: 'your.name@school.edu.ng',
      phoneNumber: '08012345678',
      department: 'e.g., Computer Science',
      level: 'e.g., 300 Level',
      matricNumber: 'e.g., 12345678',
    };
    return placeholders[fieldId] || 'Enter value';
  };

  const getFormDataKey = (fieldId: string): keyof typeof formData => {
    const map: Record<string, keyof typeof formData> = {
      fullName: 'fullName',
      regNumber: 'regNumber',
      schoolEmail: 'schoolEmail',
      phoneNumber: 'phone',
      department: 'department',
      level: 'level',
      matricNumber: 'matricNumber',
    };
    return map[fieldId] || 'fullName';
  };

  const copyAccountNumber = () => {
    if (fund) {
      navigator.clipboard.writeText(fund.bankAccountNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Handle Bank Transfer - Manual verification by host
  const handleBankTransferSubmit = () => {
    if (!fund) return;

    const newErrors: Record<string, string> = {};
    if (!formData.transactionRef.trim()) {
      newErrors.transactionRef = 'Transaction reference is required';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsProcessing(true);

    const contribution: Contribution = {
      id: Date.now().toString(),
      fullName: formData.fullName,
      regNumber: formData.regNumber,
      email: formData.email,
      phone: formData.phone,
      amount: Number(formData.amount),
      paidAt: new Date().toISOString(),
      reference: generateReference(),
      paystackReference: formData.transactionRef,
      status: 'pending',
      transactionDate: new Date().toISOString(),
      bankUsed: 'bank_transfer',
    };

    const updatedFund = { ...fund, contributions: [...fund.contributions, contribution] };
    saveFund(updatedFund);
    setSuccess(true);
    setIsProcessing(false);
  };

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    const requiredFields = fund?.requiredFields || ['fullName', 'regNumber', 'phoneNumber'];
    
    requiredFields.forEach(fieldId => {
      const formKey = getFormDataKey(fieldId);
      const value = formData[formKey];
      const label = fieldLabels[fieldId] || fieldId;
      
      if (!value || !value.trim()) {
        newErrors[formKey] = `${label} is required`;
      } else if (fieldId === 'schoolEmail' && !/\S+@\S+\.\S+/.test(value)) {
        newErrors[formKey] = 'Invalid email format';
      } else if (fieldId === 'phoneNumber' && !/^\d{10,11}$/.test(value.replace(/\D/g, ''))) {
        newErrors[formKey] = 'Invalid phone number';
      }
    });
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  if (!fund) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-600 via-purple-700 to-indigo-800 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 bg-white/10 backdrop-blur rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-white mb-3">Fund Not Found</h2>
          <p className="text-violet-200 mb-6">This contribution link is invalid or the fund has been removed. Please check the link or contact the organizer.</p>
          <button onClick={() => navigate('/')} className="bg-white text-violet-600 px-8 py-3 rounded-xl font-semibold hover:bg-violet-50 transition-all">
            Go to Homepage
          </button>
        </div>
      </div>
    );
  }

  const totalRaised = fund.contributions.reduce((sum, c) => sum + c.amount, 0);
  const progress = Math.min((totalRaised / fund.targetAmount) * 100, 100);



  if (success) {
    const lastContribution = fund.contributions[fund.contributions.length - 1];
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 text-center">
            {/* Success Icon */}
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/30">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
            <p className="text-gray-600 mb-6">Thank you for contributing to "{fund.title}"</p>
            
            {/* Payment Details */}
            <div className="bg-gray-50 rounded-xl p-5 mb-6 text-left">
              <div className="text-xs text-gray-500 mb-1">Payment Reference</div>
              <div className="font-mono text-lg font-bold text-gray-900 mb-3">{lastContribution?.reference}</div>
              <div className="border-t border-gray-200 pt-3 mt-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Amount Paid</span>
                  <span className="font-semibold text-gray-900">{formatCurrency(lastContribution?.amount || 0)}</span>
                </div>
              </div>
            </div>

            {/* Share Button */}
            <button
              onClick={() => {
                const message = `I just contributed to ${fund.title}! Join me: ${window.location.origin}/contribute/${fund.slug}`;
                window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
              }}
              className="w-full bg-green-500 text-white py-4 rounded-xl font-semibold hover:bg-green-600 transition-all flex items-center justify-center gap-2 mb-3"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Share on WhatsApp
            </button>
            
            <button
              onClick={() => navigate('/')}
              className="w-full border border-gray-300 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all"
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Fund Header - Kolekto Style */}
      <div className="bg-gradient-to-br from-violet-600 via-purple-700 to-indigo-800 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center gap-2 mb-4">
            <Link to="/" className="text-violet-200 hover:text-white transition-colors flex items-center gap-1">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span className="text-sm">Back</span>
            </Link>
          </div>
          
          <h1 className="text-2xl md:text-3xl font-bold mb-3">{fund.title}</h1>
          <p className="text-violet-100 mb-6 text-sm md:text-base">{fund.description}</p>
          
          {/* Progress Bar */}
          <div className="bg-white/10 backdrop-blur rounded-2xl p-5">
            <div className="flex justify-between items-end mb-3">
              <div>
                <div className="text-2xl md:text-3xl font-bold">{formatCurrency(totalRaised)}</div>
                <div className="text-violet-200 text-xs md:text-sm">of {formatCurrency(fund.targetAmount)} target</div>
              </div>
              <div className="text-right">
                <div className="text-xl md:text-2xl font-bold">{progress.toFixed(0)}%</div>
                <div className="text-violet-200 text-xs md:text-sm">{fund.contributions.length} contributors</div>
              </div>
            </div>
            <div className="w-full bg-white/20 rounded-full h-3">
              <div className="bg-white rounded-full h-3 transition-all" style={{ width: `${progress}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Payment Details & Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Bank Account Details Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="bg-gradient-to-r from-violet-600 to-purple-700 px-6 py-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                  </svg>
                  Payment Details
                </h3>
              </div>
              <div className="p-6">
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-gray-50 rounded-xl p-4">
                    <p className="text-xs text-gray-500 mb-1">Bank Name</p>
                    <p className="font-semibold text-gray-900 text-sm">{fund.bankName}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <p className="text-xs text-gray-500 mb-1">Account Name</p>
                    <p className="font-semibold text-gray-900 text-sm">{fund.bankAccountName}</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <p className="text-xs text-gray-500 mb-1">Account Number</p>
                    <p className="font-semibold text-gray-900 text-lg">{fund.bankAccountNumber}</p>
                  </div>
                </div>
                <div className="bg-green-50 border border-green-200 rounded-xl p-3 flex items-start gap-2">
                  <svg className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-sm text-green-800">Make your bank transfer to the account above, then complete the contribution form below</p>
                </div>
              </div>
            </div>

            {/* Contribution Form Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="bg-gradient-to-r from-violet-600 to-purple-700 px-6 py-4">
                <h3 className="text-lg font-semibold text-white">
                  {step === 1 ? 'Contributor Details' : 'Payment'}
                </h3>
              </div>
              <div className="p-6">
                {/* Step Indicator */}
                <div className="flex items-center justify-center mb-6">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center font-semibold text-xs ${step >= 1 ? 'bg-violet-600 text-white' : 'bg-gray-200 text-gray-500'}`}>1</div>
                  <div className={`w-12 h-1 mx-2 ${step >= 2 ? 'bg-violet-600' : 'bg-gray-200'}`} />
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center font-semibold text-xs ${step >= 2 ? 'bg-violet-600 text-white' : 'bg-gray-200 text-gray-500'}`}>2</div>
                </div>

                {step === 1 && (
                  <div className="space-y-5">
                    {(fund.requiredFields || ['fullName', 'regNumber', 'phoneNumber']).map((fieldId) => {
                      const formKey = getFormDataKey(fieldId);
                      const label = fieldLabels[fieldId] || fieldId;
                      const placeholder = getFieldPlaceholder(fieldId);
                      const type = fieldId === 'schoolEmail' || fieldId === 'email' ? 'email' : fieldId === 'phoneNumber' ? 'tel' : 'text';
                      
                      return (
                        <div key={fieldId}>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            {label} *
                          </label>
                          <input
                            type={type}
                            value={formData[formKey]}
                            onChange={(e) => setFormData({ ...formData, [formKey]: e.target.value })}
                            className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors[formKey] ? 'border-red-500' : 'border-gray-300'}`}
                            placeholder={placeholder}
                          />
                          {errors[formKey] && <p className="text-red-500 text-xs mt-1">{errors[formKey]}</p>}
                        </div>
                      );
                    })}

                    <button onClick={() => validateStep1() && setStep(2)} className="w-full bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all">
                      Continue to Payment
                    </button>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-5">
                    {fund.type === 'fixed' && fund.fixedAmount && (
                      <div className="bg-violet-50 border border-violet-200 rounded-xl p-4">
                        <div className="text-sm text-violet-700 mb-1">Fixed contribution amount</div>
                        <div className="text-2xl font-bold text-violet-900">{formatCurrency(fund.fixedAmount)}</div>
                      </div>
                    )}

                    {fund.type !== 'fixed' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Amount (₦) *</label>
                        <input
                          type="number"
                          value={formData.amount}
                          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                          className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.amount ? 'border-red-500' : 'border-gray-300'}`}
                          placeholder="Enter amount"
                        />
                        {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
                      </div>
                    )}

                    {fund.type === 'flexible' && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-3">Quick Select</label>
                        <div className="grid grid-cols-3 gap-2">
                          {[1000, 2000, 5000, 10000, 20000, 50000].map((amt) => (
                            <button
                              key={amt}
                              onClick={() => setFormData({ ...formData, amount: amt.toString() })}
                              className={`py-2.5 rounded-xl font-semibold text-sm border-2 transition-all ${formData.amount === amt.toString() ? 'border-violet-600 bg-violet-50 text-violet-700' : 'border-gray-200 hover:border-gray-300'}`}
                            >
                              ₦{amt.toLocaleString()}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="bg-gradient-to-r from-violet-50 to-purple-50 rounded-xl p-4 border border-violet-200">
                      <div className="text-xs text-violet-600 mb-1 font-medium">Payment Reference</div>
                      <div className="font-mono text-sm font-bold text-violet-900">{generateReference()}</div>
                    </div>

                    <button 
                      onClick={() => setShowBankDetails(true)}
                      disabled={isProcessing}
                      className="w-full bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                      Continue to Payment
                    </button>
                  </div>
                )}

                {/* Bank Transfer Details Page - SportyBet Style */}
                {showBankDetails && (
                  <div className="space-y-6">
                    <button 
                      onClick={() => setShowBankDetails(false)}
                      className="flex items-center gap-2 text-violet-600 hover:text-violet-700 font-medium transition-colors"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                      Back to Payment
                    </button>

                    <div className="bg-gradient-to-br from-violet-600 via-purple-700 to-indigo-800 rounded-2xl p-6 text-white">
                      <div className="text-sm text-violet-200 mb-2">Pay with Bank Transfer</div>
                      <div className="text-3xl font-bold mb-1">{formatCurrency(Number(formData.amount) || 0)}</div>
                      <div className="text-violet-200 text-sm">Complete your contribution</div>
                    </div>

                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                      <div className="bg-gradient-to-r from-violet-600 to-purple-700 px-6 py-4">
                        <h3 className="text-lg font-semibold text-white">Transfer to the following account</h3>
                      </div>
                      <div className="p-6">
                        <div className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-2xl p-6 border-2 border-violet-200 mb-6">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-gradient-to-br from-violet-600 to-purple-700 rounded-xl flex items-center justify-center">
                              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                              </svg>
                            </div>
                            <div>
                              <div className="text-sm text-violet-600 font-medium">Bank Name</div>
                              <div className="text-xl font-bold text-gray-900">{fund.bankName}</div>
                            </div>
                          </div>

                          <div className="mb-4">
                            <div className="text-sm text-violet-600 font-medium mb-2">Account Number</div>
                            <div className="flex items-center gap-3">
                              <div className="text-3xl font-mono font-bold text-violet-900 tracking-wider">{fund.bankAccountNumber}</div>
                              <button 
                                onClick={copyAccountNumber}
                                className="px-4 py-2 border-2 border-violet-600 text-violet-600 rounded-lg font-semibold hover:bg-violet-50 transition-all text-sm"
                              >
                                {copied ? 'Copied!' : 'Copy'}
                              </button>
                            </div>
                          </div>

                          <div>
                            <div className="text-sm text-violet-600 font-medium mb-1">Account Name</div>
                            <div className="text-lg font-semibold text-gray-900">{fund.bankAccountName}</div>
                          </div>
                        </div>

                        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
                          <div className="flex items-start gap-3">
                            <svg className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                            </svg>
                            <div className="text-sm text-amber-800">
                              <div className="font-semibold mb-1">Important:</div>
                              <div className="text-amber-700">Transfer the exact amount ({formatCurrency(Number(formData.amount) || 0)}) to the account above. Your payment will be verified by the host before being added to the contributors list.</div>
                            </div>
                          </div>
                        </div>

                        <div className="mb-6">
                          <label className="block text-sm font-medium text-gray-700 mb-2">Transaction Reference *</label>
                          <input
                            type="text"
                            value={formData.transactionRef}
                            onChange={(e) => setFormData({ ...formData, transactionRef: e.target.value })}
                            className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-violet-500 focus:border-transparent ${errors.transactionRef ? 'border-red-500' : 'border-gray-300'}`}
                            placeholder="Enter transaction reference from your bank app"
                          />
                          {errors.transactionRef && <p className="text-red-500 text-xs mt-1">{errors.transactionRef}</p>}
                          <p className="text-xs text-gray-500 mt-2">Find this in your bank app after making the transfer</p>
                        </div>

                        <button 
                          onClick={handleBankTransferSubmit}
                          disabled={isProcessing}
                          className="w-full bg-gradient-to-r from-green-600 to-emerald-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-green-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                          {isProcessing ? (
                            <>
                              <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                              </svg>
                              Processing...
                            </>
                          ) : (
                            <>
                              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              I've Made Payment
                            </>
                          )}
                        </button>

                        <p className="text-xs text-gray-500 text-center mt-4">
                          After clicking, your payment will be pending until the host confirms receipt in their bank account
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column - Organizer Info & Contributors */}
          <div className="space-y-6">
            {/* Organizer Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4 text-sm uppercase tracking-wide text-gray-500">Organized by</h3>
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-violet-600 to-purple-700 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">{fund.hostName.charAt(0)}</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">{fund.hostName}</div>
                  <div className="text-sm text-gray-600">{fund.course}</div>
                  <div className="text-xs text-gray-500">{fund.department}</div>
                </div>
              </div>
            </div>

            {/* Contributors Card */}
            {fund.contributions.length > 0 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-900 mb-4 text-sm uppercase tracking-wide text-gray-500">
                  Contributors ({fund.contributions.length})
                </h3>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {fund.contributions.slice(-10).reverse().map((c) => (
                    <div key={c.id} className="flex justify-between items-center py-3 border-b border-gray-100 last:border-0">
                      <div>
                        <div className="font-medium text-gray-900 text-sm">{c.fullName}</div>
                        <div className="text-xs text-gray-500">{c.regNumber}</div>
                      </div>
                      <div className="font-semibold text-violet-600 text-sm">{formatCurrency(c.amount)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Fund Info Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <h3 className="font-semibold text-gray-900 mb-4 text-sm uppercase tracking-wide text-gray-500">Fund Details</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Target</span>
                  <span className="text-sm font-semibold text-gray-900">{formatCurrency(fund.targetAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Deadline</span>
                  <span className="text-sm font-semibold text-gray-900">{formatDate(fund.deadline)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Type</span>
                  <span className="text-sm font-semibold text-gray-900 capitalize">{fund.type}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Dashboard Page
const DashboardPage: React.FC = () => {
  const funds = getFunds();
  const navigate = useNavigate();

  const totalFunds = funds.length;
  const totalRaisedAll = funds.reduce((sum, f) => sum + f.contributions.reduce((s, c) => s + c.amount, 0), 0);
  const totalContributors = funds.reduce((sum, f) => sum + f.contributions.filter(c => c.status === 'verified').length, 0);
  const activeFunds = funds.filter(f => new Date(f.deadline) > new Date()).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-violet-50 to-purple-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Welcome Back! 🎓</h1>
          <p className="text-gray-600">Manage your class funds and track contributions</p>
        </motion.div>

        {/* University Stats Cards */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-violet-500/10 transition-all group">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <span className="text-xs text-green-600 font-semibold bg-green-100 px-2 py-1 rounded-full">All Time</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">{totalFunds}</div>
            <div className="text-xs text-gray-500 mt-1">Total Funds Created</div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-violet-500/10 transition-all group">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <span className="text-xs text-green-600 font-semibold bg-green-100 px-2 py-1 rounded-full">Verified</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">{formatCurrency(totalRaisedAll)}</div>
            <div className="text-xs text-gray-500 mt-1">Total Amount Raised</div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-violet-500/10 transition-all group">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
              <span className="text-xs text-blue-600 font-semibold bg-blue-100 px-2 py-1 rounded-full">Students</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">{totalContributors}</div>
            <div className="text-xs text-gray-500 mt-1">Total Contributors</div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-violet-500/10 transition-all group">
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <span className="text-xs text-orange-600 font-semibold bg-orange-100 px-2 py-1 rounded-full">Active</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">{activeFunds}</div>
            <div className="text-xs text-gray-500 mt-1">Active Funds</div>
          </div>
        </motion.div>

        {/* Funds Grid */}
        {funds.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">No Funds Yet</h2>
            <p className="text-gray-600 mb-6">Create your first fund to start collecting contributions from classmates</p>
            <button 
              onClick={() => navigate('/create')}
              className="bg-gradient-to-r from-violet-600 to-purple-700 text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-violet-500/30 transition-all inline-flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Create Fund
            </button>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {funds.map((fund, index) => {
              const verifiedTotal = fund.contributions.filter(c => c.status === 'verified').reduce((sum, c) => sum + c.amount, 0);
              const progress = Math.min((verifiedTotal / fund.targetAmount) * 100, 100);
              
              return (
                <motion.div
                  key={fund.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ y: -5, boxShadow: '0 10px 40px rgba(139, 92, 246, 0.15)' }}
                  className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 cursor-pointer transition-all"
                  onClick={() => navigate(`/dashboard/${fund.id}`)}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 text-lg mb-1">{fund.title}</h3>
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        fund.type === 'fixed' ? 'bg-blue-100 text-blue-700' : 
                        fund.type === 'flexible' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'
                      }`}>
                        {fund.type}
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{fund.description}</p>
                  
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">{formatCurrency(verifiedTotal)} raised</span>
                      <span className="text-gray-600 font-medium">{progress.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 1, delay: 0.3 }}
                        className="bg-gradient-to-r from-violet-600 to-purple-700 rounded-full h-full" 
                      />
                    </div>
                  </div>

                  <div className="flex justify-between text-sm text-gray-600 mb-4">
                    <span className="flex items-center gap-1">
                      <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"/>
                      </svg>
                      {fund.contributions.filter(c => c.status === 'verified').length} verified
                    </span>
                    <span className="flex items-center gap-1">
                      <svg className="w-4 h-4 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"/>
                      </svg>
                      {formatDate(fund.deadline)}
                    </span>
                  </div>

                  <div className="flex gap-2 pt-4 border-t border-gray-100">
                    <button
                      onClick={(e) => { e.stopPropagation(); navigate(`/dashboard/${fund.id}`); }}
                      className="flex-1 bg-gradient-to-r from-violet-600 to-purple-700 text-white py-2.5 rounded-xl font-semibold text-sm hover:shadow-lg hover:shadow-violet-500/30 transition-all text-center"
                    >
                      View Dashboard
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); navigate(`/fund/${fund.id}/share`); }}
                      className="px-4 border border-gray-300 text-gray-700 py-2.5 rounded-xl font-semibold text-sm hover:bg-gray-50 transition-all"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                      </svg>
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </div>
    </div>
  );
};

// Fund Dashboard (Detailed) - Kolekto Style
const FundDashboardPage: React.FC = () => {
  const { fundId } = useParams<{ fundId: string }>();
  const navigate = useNavigate();
  const fund = getFundById(fundId || '');

  const [copied, setCopied] = useState(false);

  if (!fund) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Fund not found</h2>
          <button onClick={() => navigate('/dashboard')} className="text-violet-600 hover:underline">Back to Dashboard</button>
        </div>
      </div>
    );
  }

  const totalRaised = fund.contributions.reduce((sum, c) => sum + c.amount, 0);
  const verifiedTotal = fund.contributions.filter(c => c.status === 'verified').reduce((sum, c) => sum + c.amount, 0);
  const progress = Math.min((verifiedTotal / fund.targetAmount) * 100, 100);
  const contributeUrl = `${window.location.origin}/contribute/${fund.slug}`;
  const pendingContributions = fund.contributions.filter(c => c.status === 'pending');
  const verifiedContributions = fund.contributions.filter(c => c.status === 'verified');

  const verifyPayment = (contributionId: string) => {
    if (confirm('Verify this payment? Make sure you have received the money in your bank account.')) {
      const updatedFund = { ...fund, contributions: fund.contributions.map(c => c.id === contributionId ? { ...c, status: 'verified' as const } : c) };
      saveFund(updatedFund);
      window.location.reload();
    }
  };

  const rejectPayment = (contributionId: string) => {
    if (confirm('Reject this payment? The contributor will need to make payment again.')) {
      const updatedFund = { ...fund, contributions: fund.contributions.map(c => c.id === contributionId ? { ...c, status: 'rejected' as const } : c) };
      saveFund(updatedFund);
      window.location.reload();
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(contributeUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const exportToCSV = () => {
    const headers = ['Name', 'Reg Number', 'Email', 'Phone', 'Amount', 'Reference', 'Date'];
    const rows = fund.contributions.map(c => [
      c.fullName,
      c.regNumber,
      c.email,
      c.phone,
      c.amount.toString(),
      c.reference,
      new Date(c.paidAt).toLocaleDateString(),
    ]);
    
    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fund.slug}-contributors.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-violet-50 to-purple-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <motion.button 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate('/dashboard')} 
          className="flex items-center text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Dashboard
        </motion.button>

        {/* Fund Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{fund.title}</h1>
          <p className="text-gray-600">{fund.description}</p>
        </motion.div>

        {/* Stats Cards with University Icons */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6"
        >
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-green-500/10 transition-all group">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="text-xs text-gray-500">Verified</div>
            </div>
            <div className="text-xl md:text-2xl font-bold text-green-600">{formatCurrency(verifiedTotal)}</div>
            <div className="text-xs text-gray-500 mt-1">{verifiedContributions.length} confirmed</div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-orange-500/10 transition-all group">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="text-xs text-gray-500">Pending</div>
            </div>
            <div className="text-xl md:text-2xl font-bold text-orange-600">{pendingContributions.length}</div>
            <div className="text-xs text-gray-500 mt-1">Awaiting verification</div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-blue-500/10 transition-all group">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="text-xs text-gray-500">Total</div>
            </div>
            <div className="text-xl md:text-2xl font-bold text-gray-900">{formatCurrency(totalRaised)}</div>
            <div className="text-xs text-gray-500 mt-1">All payments</div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-purple-500/10 transition-all group">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-violet-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <div className="text-xs text-gray-500">Target</div>
            </div>
            <div className="text-xl md:text-2xl font-bold text-gray-900">{formatCurrency(fund.targetAmount)}</div>
            <div className="text-xs text-gray-500 mt-1">Goal amount</div>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg hover:shadow-violet-500/10 transition-all group">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-purple-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div className="text-xs text-gray-500">Progress</div>
            </div>
            <div className="text-xl md:text-2xl font-bold text-violet-600">{progress.toFixed(0)}%</div>
            <div className="text-xs text-gray-500 mt-1">Of target</div>
          </div>
        </motion.div>

        {/* Progress Bar */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6"
        >
          <div className="flex justify-between text-xs mb-2">
            <span className="text-gray-600">Verified Progress</span>
            <span className="text-gray-600 font-medium">{progress.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 1, delay: 0.3 }}
              className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-full h-3" 
            />
          </div>
          <div className="flex justify-between text-xs text-gray-500 mt-2">
            <span>{formatCurrency(verifiedTotal)} verified</span>
            <span>{formatCurrency(fund.targetAmount - verifiedTotal)} remaining</span>
          </div>
        </motion.div>

        {/* Bank Account Details */}
        <div className="bg-gradient-to-br from-violet-600 to-purple-700 rounded-xl shadow-lg p-5 mb-6 text-white">
          <h2 className="text-base font-semibold mb-3 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
            </svg>
            Bank Account Details
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-white/10 backdrop-blur rounded-lg p-3">
              <p className="text-violet-200 text-xs mb-1">Bank Name</p>
              <p className="font-semibold text-sm">{fund.bankName}</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-3">
              <p className="text-violet-200 text-xs mb-1">Account Name</p>
              <p className="font-semibold text-sm">{fund.bankAccountName}</p>
            </div>
            <div className="bg-white/10 backdrop-blur rounded-lg p-3">
              <p className="text-violet-200 text-xs mb-1">Account Number</p>
              <p className="font-semibold text-base">{fund.bankAccountNumber}</p>
            </div>
          </div>
        </div>

        {/* Share Link */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6">
          <h2 className="text-base font-semibold text-gray-900 mb-3">Share Your Fund</h2>
          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={contributeUrl}
              readOnly
              className="flex-1 px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-700"
            />
            <button
              onClick={handleCopy}
              className={`px-5 py-2.5 rounded-lg font-semibold text-sm transition-all ${copied ? 'bg-green-600 text-white' : 'bg-violet-600 text-white hover:bg-violet-700'}`}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(`Contribute to ${fund.title}: ${contributeUrl}`)}`, '_blank')}
              className="flex-1 bg-green-500 text-white py-2.5 rounded-lg font-semibold text-sm hover:bg-green-600 transition-all"
            >
              WhatsApp
            </button>
            <button
              onClick={() => window.open(`mailto:?subject=${encodeURIComponent(`Contribute to ${fund.title}`)}&body=${encodeURIComponent(contributeUrl)}`, '_blank')}
              className="flex-1 bg-blue-500 text-white py-2.5 rounded-lg font-semibold text-sm hover:bg-blue-600 transition-all"
            >
              Email
            </button>
            <button
              onClick={exportToCSV}
              className="flex-1 bg-gray-700 text-white py-2.5 rounded-lg font-semibold text-sm hover:bg-gray-800 transition-all"
            >
              Export CSV
            </button>
          </div>
        </div>

        {/* Pending Payments Verification */}
        {pendingContributions.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-orange-200 overflow-hidden mb-6">
            <div className="px-5 py-4 border-b border-orange-200 bg-orange-50">
              <h2 className="text-base font-semibold text-orange-800 flex items-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Pending Verification ({pendingContributions.length})
              </h2>
              <p className="text-sm text-orange-600 mt-1">Verify these payments after confirming receipt in your bank account</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-orange-50">
                  <tr>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-orange-700 uppercase">Name</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-orange-700 uppercase">Reg Number</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-orange-700 uppercase">Amount</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-orange-700 uppercase">Reference</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-orange-700 uppercase">Date</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-orange-700 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingContributions.map((c) => (
                    <tr key={c.id} className="border-b border-orange-100 last:border-0 hover:bg-orange-50">
                      <td className="py-3 px-4 text-sm text-gray-900">
                        <div>
                          <p className="font-medium">{c.fullName}</p>
                          <p className="text-xs text-gray-500">{c.email}</p>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-sm text-gray-700">{c.regNumber}</td>
                      <td className="py-3 px-4 text-sm font-semibold text-orange-600">{formatCurrency(c.amount)}</td>
                      <td className="py-3 px-4 text-sm text-gray-700 font-mono">{c.reference}</td>
                      <td className="py-3 px-4 text-sm text-gray-700">{formatDate(c.paidAt)}</td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <button
                            onClick={() => verifyPayment(c.id)}
                            className="px-3 py-1.5 bg-green-600 text-white text-xs font-semibold rounded-lg hover:bg-green-700 transition-all flex items-center gap-1"
                          >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            Verify
                          </button>
                          <button
                            onClick={() => rejectPayment(c.id)}
                            className="px-3 py-1.5 bg-red-600 text-white text-xs font-semibold rounded-lg hover:bg-red-700 transition-all flex items-center gap-1"
                          >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                            Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Verified Contributors Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="text-base font-semibold text-gray-900">Verified Contributors ({verifiedContributions.length})</h2>
          </div>
          
          {verifiedContributions.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <p className="text-gray-600">No verified contributions yet</p>
              <p className="text-sm text-gray-500">Verify pending payments to see them here</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Name</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Reg Number</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Email</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Phone</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Amount</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Reference</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Date</th>
                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-600 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {verifiedContributions.map((c) => (
                    <tr key={c.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm text-gray-900">{c.fullName}</td>
                      <td className="py-3 px-4 text-sm text-gray-700">{c.regNumber}</td>
                      <td className="py-3 px-4 text-sm text-gray-700">{c.email}</td>
                      <td className="py-3 px-4 text-sm text-gray-700">{c.phone}</td>
                      <td className="py-3 px-4 text-sm font-semibold text-green-600">{formatCurrency(c.amount)}</td>
                      <td className="py-3 px-4 text-sm text-gray-700 font-mono">{c.reference}</td>
                      <td className="py-3 px-4 text-sm text-gray-700">{formatDate(c.paidAt)}</td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                          <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                          Verified
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Payment Callback Component - Handles Paystack Hosted Checkout Response
const PaymentCallbackPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [status, setStatus] = useState<'checking' | 'success' | 'failed'>('checking');
  const [fund, setFund] = useState<Fund | null>(null);

  useEffect(() => {
    const checkPayment = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const reference = urlParams.get('reference');

      if (!reference) {
        setStatus('failed');
        return;
      }

      // Get pending contribution data from sessionStorage
      const pendingData = sessionStorage.getItem('pending_contribution_' + reference);
      
      if (!pendingData) {
        setStatus('failed');
        return;
      }

      const pending = JSON.parse(pendingData);
      const foundFund = getFundById(pending.fundId);

      if (!foundFund) {
        setStatus('failed');
        return;
      }

      setFund(foundFund);

      // Payment already verified by Paystack inline popup
      // Save contribution directly
      const contribution: Contribution = {
        id: Date.now().toString(),
        fullName: pending.fullName,
        regNumber: pending.regNumber,
        email: pending.email,
        phone: pending.phone,
        amount: pending.amount,
        paidAt: new Date().toISOString(),
        reference: reference,
        paystackReference: reference,
        status: 'verified',
        transactionDate: new Date().toISOString(),
        bankUsed: 'bank_transfer',
      };

      foundFund.contributions.push(contribution);
      saveFund(foundFund);
      sessionStorage.removeItem('pending_contribution_' + reference);
      setStatus('success');
    };

    checkPayment();
  }, [slug]);

  if (status === 'checking') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <svg className="animate-spin h-12 w-12 text-violet-600 mx-auto mb-4" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
          </svg>
          <h2 className="text-xl font-semibold text-gray-900">Verifying Payment...</h2>
          <p className="text-gray-600 mt-2">Please wait while we confirm your payment</p>
        </div>
      </div>
    );
  }

  if (status === 'success' && fund) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/30">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
            <p className="text-gray-600 mb-6">Thank you for contributing to "{fund.title}"</p>
            
            <div className="bg-gray-50 rounded-xl p-5 mb-6 text-left">
              <div className="text-xs text-gray-500 mb-1">Payment Reference</div>
              <div className="font-mono text-lg font-bold text-gray-900 mb-3">{fund.contributions[fund.contributions.length - 1]?.reference}</div>
              <div className="border-t border-gray-200 pt-3 mt-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Amount Paid</span>
                  <span className="font-semibold text-gray-900">{formatCurrency(fund.contributions[fund.contributions.length - 1]?.amount || 0)}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                const message = `I just contributed to ${fund.title}! Join me: ${window.location.origin}/contribute/${fund.slug}`;
                window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
              }}
              className="w-full bg-green-500 text-white py-4 rounded-xl font-semibold hover:bg-green-600 transition-all flex items-center justify-center gap-2 mb-3"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Share on WhatsApp
            </button>
            
            <button
              onClick={() => navigate('/')}
              className="w-full border border-gray-300 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-50 transition-all"
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12">
      <div className="max-w-md mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-red-500/30">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Payment Failed</h1>
          <p className="text-gray-600 mb-6">We couldn't verify your payment. Please try again.</p>
          
          <button
            onClick={() => navigate(`/contribute/${slug}`)}
            className="w-full bg-gradient-to-r from-violet-600 to-purple-700 text-white py-4 rounded-xl font-semibold hover:shadow-lg transition-all"
          >
            Try Again
          </button>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/create" element={<CreateFundPage />} />
        <Route path="/fund/:fundId/share" element={<ShareFundPage />} />
        <Route path="/contribute/:slug" element={<ContributePage />} />
        <Route path="/payment/callback/:slug" element={<PaymentCallbackPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/dashboard/:fundId" element={<FundDashboardPage />} />
      </Routes>
    </Router>
  );
};

export default App;